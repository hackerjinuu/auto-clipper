package com.jare.autoclipper.model

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import com.jare.autoclipper.App
import com.jare.autoclipper.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.TimeUnit

/**
 * Keeps the Parakeet model inside the app (internal storage). It is downloaded from your
 * Cloudflare R2 bucket exactly once (resumable), then always loaded from the phone.
 */
class ModelManager(private val ctx: Context) {
    companion object {
        const val DEFAULT_BASE = "https://pub-cffd9b31b5de4a139c407d69c24d4654.r2.dev"
        const val ENCODER = "encoder-model.int8.onnx"
        const val DECODER = "decoder_joint-model.int8.onnx"
        const val VOCAB = "vocab.txt"
        val FILES = listOf(ENCODER, DECODER, VOCAB)
        const val WORK = "parakeet-download"
        const val CHANNEL = "model_download"
    }

    val dir = File(ctx.filesDir, "models/parakeet-tdt-0.6b-v2-int8").apply { mkdirs() }
    private val marker get() = File(dir, "ready.json")

    fun isReady(): Boolean = marker.exists() && FILES.all { File(dir, it).length() > 0 }

    fun sizeOnDisk(): Long = dir.listFiles()?.sumOf { it.length() } ?: 0L

    fun start(wifiOnly: Boolean = false) {
        val req = OneTimeWorkRequestBuilder<ModelDownloadWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(if (wifiOnly) NetworkType.UNMETERED else NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(ctx).enqueueUniqueWork(WORK, ExistingWorkPolicy.KEEP, req)
    }

    fun cancel() = WorkManager.getInstance(ctx).cancelUniqueWork(WORK)

    fun progress(): Flow<List<WorkInfo>> = WorkManager.getInstance(ctx).getWorkInfosForUniqueWorkFlow(WORK)

    fun delete() {
        com.jare.autoclipper.asr.ParakeetEngine.unload()
        dir.listFiles()?.forEach { it.delete() }
    }

    internal fun markReady(sizes: Map<String, Long>) {
        marker.writeText(JSONObject(sizes as Map<*, *>).toString())
    }
}

class ModelDownloadWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    private val nid = 4107

    private fun notif(text: String, pct: Int): ForegroundInfo {
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(ModelManager.CHANNEL) == null)
            nm.createNotificationChannel(NotificationChannel(ModelManager.CHANNEL, "Model download", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(applicationContext, ModelManager.CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("Downloading Parakeet model")
            .setContentText(text)
            .setOnlyAlertOnce(true).setOngoing(true)
            .setProgress(100, pct.coerceIn(0, 100), pct < 0)
            .build()
        return ForegroundInfo(nid, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    }

    override suspend fun getForegroundInfo(): ForegroundInfo = notif("Starting…", -1)

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val mm = ModelManager(applicationContext)
        if (mm.isReady()) return@withContext Result.success()
        runCatching { setForeground(notif("Starting…", -1)) }
        val base = App.prefs.modelBase.trim().trimEnd('/').ifEmpty { ModelManager.DEFAULT_BASE }
        val http = OkHttpClient.Builder().connectTimeout(30, TimeUnit.SECONDS).readTimeout(60, TimeUnit.SECONDS).retryOnConnectionFailure(true).build()
        try {
            // sizes first, so progress covers all three files
            val sizes = LinkedHashMap<String, Long>()
            for (f in ModelManager.FILES) {
                sizes[f] = try {
                    http.newCall(Request.Builder().url("$base/$f").head().build()).execute().use { r ->
                        if (r.code == 404) throw IOException("$f not found at $base (check the model address in Settings)")
                        if (r.isSuccessful) r.header("Content-Length")?.toLongOrNull() ?: -1L else -1L
                    }
                } catch (e: IOException) { if (e.message?.contains("not found") == true) throw e else -1L }
            }
            val total = sizes.values.sumOf { if (it > 0) it else 0L }.coerceAtLeast(1L)
            var doneBefore = 0L
            var lastUi = 0L
            for (f in ModelManager.FILES) {
                val target = File(mm.dir, f)
                val expect = sizes[f] ?: -1L
                if (target.exists() && expect > 0 && target.length() == expect) { doneBefore += expect; continue }
                target.delete()
                val part = File(mm.dir, "$f.part")
                var have = if (part.exists()) part.length() else 0L
                if (expect > 0 && have > expect) { part.delete(); have = 0 }
                val rb = Request.Builder().url("$base/$f")
                if (have > 0) rb.header("Range", "bytes=$have-")
                http.newCall(rb.build()).execute().use { r ->
                    if (r.code == 416 && expect > 0 && have == expect) return@use
                    if (!r.isSuccessful) throw IOException("$f: HTTP ${r.code}")
                    if (have > 0 && r.code != 206) have = 0 // server ignored the range: restart this file
                    RandomAccessFile(part, "rw").use { raf ->
                        raf.setLength(have); raf.seek(have)
                        val inp = r.body!!.byteStream()
                        val buf = ByteArray(1 shl 16)
                        while (true) {
                            if (isStopped) throw IOException("stopped")
                            val n = inp.read(buf); if (n < 0) break
                            raf.write(buf, 0, n); have += n
                            val now = System.currentTimeMillis()
                            if (now - lastUi > 500) {
                                lastUi = now
                                val done = doneBefore + have
                                val pct = (done * 100 / total).toInt()
                                setProgress(workDataOf("done" to done, "total" to total, "file" to f))
                                runCatching { setForeground(notif("$f · ${done / 1_048_576} / ${total / 1_048_576} MB", pct)) }
                            }
                        }
                    }
                }
                if (expect > 0 && part.length() != expect) throw IOException("$f: incomplete (${part.length()} of $expect bytes)")
                if (!part.renameTo(target)) throw IOException("Could not save $f")
                doneBefore += target.length()
            }
            mm.markReady(ModelManager.FILES.associateWith { File(mm.dir, it).length() })
            setProgress(workDataOf("done" to total, "total" to total, "file" to "done"))
            Result.success()
        } catch (e: Exception) {
            if (isStopped) Result.failure(workDataOf("error" to "Cancelled"))
            else if (runAttemptCount < 6) Result.retry()
            else Result.failure(workDataOf("error" to (e.message ?: e.toString())))
        }
    }
}
