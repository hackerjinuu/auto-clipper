package com.jare.autoclipper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Bg = Color(0xFF0E0F11)
val Panel = Color(0xFF16171A)
val Raise = Color(0xFF1F2125)
val Line = Color(0xFF2A2D33)
val Tx = Color(0xFFECECEE)
val Mut = Color(0xFF8D929B)
val Acc = Color(0xFFB8FF3D)

@Composable
fun ClipperTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Acc, onPrimary = Color(0xFF10120A), background = Bg, onBackground = Tx,
            surface = Panel, onSurface = Tx, surfaceVariant = Raise, onSurfaceVariant = Mut, outline = Line, secondary = Acc,
        ),
        content = content,
    )
}

@Composable
fun SectionCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp)
            .background(Panel, RoundedCornerShape(10.dp))
            .border(1.dp, Line, RoundedCornerShape(10.dp))
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(3.dp).height(14.dp).background(Acc, RoundedCornerShape(2.dp)))
            Spacer(Modifier.width(8.dp))
            Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = Tx)
        }
        Spacer(Modifier.height(6.dp))
        content()
    }
}

@Composable
fun Label(t: String) = Text(t, color = Mut, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 2.dp))

@Composable
fun Note(t: String) { if (t.isNotEmpty()) Text(t, color = Mut, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }

@Composable
fun LSlider(label: String, value: Double, range: ClosedFloatingPointRange<Double>, step: Double = 0.0, fmt: (Double) -> String = { "%.0f".format(it) }, onChange: (Double) -> Unit, onDone: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Mut, fontSize = 12.sp, modifier = Modifier.weight(1f).padding(top = 8.dp))
        Text(fmt(value), color = Tx, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
    val steps = if (step > 0) (((range.endInclusive - range.start) / step).toInt() - 1).coerceIn(0, 200) else 0
    Slider(
        value = value.toFloat(),
        onValueChange = { onChange(it.toDouble()) },
        onValueChangeFinished = onDone,
        valueRange = range.start.toFloat()..range.endInclusive.toFloat(),
        steps = steps,
        colors = SliderDefaults.colors(thumbColor = Acc, activeTrackColor = Acc, inactiveTrackColor = Color(0xFF33363D)),
        modifier = Modifier.height(30.dp)
    )
}

@Composable
fun CheckRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Checkbox(checked = checked, onCheckedChange = onChange, colors = CheckboxDefaults.colors(checkedColor = Acc, checkmarkColor = Color.Black))
        Text(label, color = Tx, fontSize = 13.sp)
    }
}

@Composable
fun <T> Choice(label: String, options: List<Pair<T, String>>, selected: T, onSelect: (T) -> Unit, modifier: Modifier = Modifier) {
    var open by remember { mutableStateOf(false) }
    Column(modifier) {
        Label(label)
        Box {
            OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(7.dp)) {
                Text(options.firstOrNull { it.first == selected }?.second ?: selected.toString(), color = Tx, fontSize = 13.sp, maxLines = 1, modifier = Modifier.weight(1f))
                Text("▾", color = Mut)
            }
            DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                options.forEach { (v, t) -> DropdownMenuItem(text = { Text(t) }, onClick = { open = false; onSelect(v) }) }
            }
        }
    }
}

@Composable
fun NumField(label: String, value: Double, modifier: Modifier = Modifier, onValue: (Double) -> Unit) {
    fun fmt(v: Double) = if (v % 1.0 == 0.0) v.toInt().toString() else "%.1f".format(v)
    var txt by remember { mutableStateOf(fmt(value)) }
    LaunchedEffect(value) { if (txt.replace(',', '.').toDoubleOrNull() != value) txt = fmt(value) }
    OutlinedTextField(
        value = txt,
        onValueChange = { v -> txt = v; v.replace(',', '.').toDoubleOrNull()?.let(onValue) },
        label = { Text(label, fontSize = 11.sp) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

@Composable
fun AccButton(text: String, busy: Boolean = false, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Button(
        onClick = onClick, enabled = enabled && !busy, modifier = modifier, shape = RoundedCornerShape(7.dp),
        colors = ButtonDefaults.buttonColors(containerColor = Acc, contentColor = Color(0xFF10120A), disabledContainerColor = Acc.copy(alpha = 0.5f))
    ) {
        if (busy) CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = Color.Black)
        else Text(text, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun PlainButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, enabled = enabled, modifier = modifier, shape = RoundedCornerShape(7.dp)) { Text(text, color = Tx, maxLines = 1) }
}

@Composable
fun Row2(content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) =
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically, content = content)
