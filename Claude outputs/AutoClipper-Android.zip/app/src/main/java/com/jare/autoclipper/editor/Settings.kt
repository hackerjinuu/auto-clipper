package com.jare.autoclipper.editor

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Every control of the web editor, as observable state (defaults match index.html). */
class Settings {
    // 1 · Source video
    var st by mutableDoubleStateOf(0.0)          // start (s)
    var ln by mutableDoubleStateOf(30.0)         // max length (s)
    var cut by mutableStateOf(false)             // auto-cut silence
    var sth by mutableDoubleStateOf(26.0)        // cut strength 12..40
    var sgp by mutableDoubleStateOf(0.35)        // min silence to cut
    var cx by mutableDoubleStateOf(0.5)          // picture focus left/right

    // Frame · Hook · Handle
    var rt by mutableStateOf("7:6")
    var hk by mutableStateOf("Cortisol could be sabotaging your steroid cycle.")
    var hd by mutableStateOf("yt @diagofit")
    var hs by mutableDoubleStateOf(76.0)
    var vw by mutableDoubleStateOf(100.0)
    var cy by mutableDoubleStateOf(0.0)
    var vo by mutableDoubleStateOf(0.0)

    // 2 · Transcript
    var tr by mutableStateOf("")
    var bon by mutableStateOf(true)
    var bbp by mutableStateOf(true)
    var bw by mutableStateOf("")

    // 3 · Captions
    var sty by mutableStateOf("kinetic")
    var wn by mutableIntStateOf(3)
    var fn by mutableIntStateOf(0)
    var fs by mutableDoubleStateOf(96.0)
    var co by mutableDoubleStateOf(0.0)
    var fy by mutableDoubleStateOf(84.0)
    var up by mutableStateOf(true)
    var hc by mutableStateOf(0xFFFFE14D.toInt())

    // 4 · B-roll
    var brmax by mutableDoubleStateOf(2.0)

    // 5 · Zoom · Music · SFX
    var zm by mutableStateOf("none")
    var zs by mutableDoubleStateOf(20.0)
    var zd by mutableDoubleStateOf(2.0)
    var zw by mutableStateOf(false)
    var bsel by mutableStateOf("auto")
    var bv by mutableDoubleStateOf(0.22)
    var sfxcut by mutableStateOf(true)

    /** Style presets: ALL CAPS, highlight colour, font */
    fun applyPreset(style: String) {
        sty = style
        when (style) {
            "kinetic" -> { up = true; hc = 0xFFFFE14D.toInt(); fn = 0 }
            "karaoke" -> { up = true; hc = 0xFFB8FF3D.toInt(); fn = 1 }
            "box" -> { up = false; hc = 0xFFFFE14D.toInt(); fn = 1 }
            "minimal" -> { up = false; hc = 0xFFFFFFFF.toInt(); fn = 2 }
            "redkw" -> { up = true; hc = 0xFFFF3B3B.toInt(); fn = 0 }
        }
    }

    companion object {
        val RATIOS = listOf("1:1" to "1:1 (square)", "7:6" to "7:6 (like reference)", "4:5" to "4:5", "4:3" to "4:3", "16:9" to "16:9", "9:16" to "9:16", "full" to "Full screen (no frame)")
        val FR = mapOf("1:1" to 1.0, "7:6" to 7.0 / 6, "4:5" to 4.0 / 5, "4:3" to 4.0 / 3, "16:9" to 16.0 / 9, "9:16" to 9.0 / 16)
        val STYLES = listOf("kinetic" to "Kinetic (bold + keyword)", "karaoke" to "Karaoke (spoken word)", "box" to "Box subtitle", "minimal" to "Minimal clean", "redkw" to "Red keyword")
        val FONTS = listOf("Condensed Black (Impact-like)", "Black (Arial Black-like)", "Serif (Georgia-like)")
    }
}
