package com.jare.autoclipper.editor

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jare.autoclipper.App
import com.jare.autoclipper.asr.ParakeetEngine
import com.jare.autoclipper.media.AudioDecoder
import com.jare.autoclipper.media.Exporter
import com.jare.autoclipper.media.FloatList
import com.jare.autoclipper.media.FrameSource
import com.jare.autoclipper.media.MediaUtil
import com.jare.autoclipper.model.ModelManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.random.Random

data class TaskUi(val text: String, val state: Int /*0 running, 1 ok, 2 error*/, val pct: Float?)
data class HookItem(val seg: Seg, val badge: String?)
data class ExportUi(val stage: Int /*0 options, 1 running, 2 done, 3 stopped*/, val res: Int = 1080, val fps: Int = 30, val pct: Float = 0f,
                    val title: String = "", val note: String = "", val outUri: Uri? = null, val outName: String = "")

/** The whole editor (web: the big <script> of index.html). */
class EditorViewModel(app: Application) : AndroidViewModel(app), Project {
    val ctx: Context get() = getApplication()
    override val s = Settings()
    val preview = PreviewEngine(this)
    private val main = Handler(Looper.getMainLooper())
    fun post(r: () -> Unit) { main.post { r() } }

    companion object {
        const val SN_DEFAULT = "Removes pauses so the clip jumps from speech to speech. Max length = final length after cuts."
        const val HKN_DEFAULT = "Listens to the first 3 minutes and lists every spoken line. The top 3 are suggested, and the best is applied first. Tap any line to start the clip there instead."
        const val ASRN_DEFAULT = "Uses NVIDIA Parakeet TDT 0.6B v2 (INT8) stored on this phone, running natively with ONNX Runtime."
        const val BRN_DEFAULT = "Reads the \"broll\" folder of your library. A clip named blood_01.mp4 / blood1.mp4 is shown when a caption says \"blood\". Several numbered files for one keyword are used in turn."
        private const val PCM_CAP = 60 * 60 * 16000 // keep at most 60 min of 16 kHz audio in memory
    }

    /* ---------------- source ---------------- */
    var srcUri: Uri? = null; private set
    var srcName by mutableStateOf("")
    var dur = 0.0; private set
    override val hasVideo get() = srcUri != null && dur > 0
    @Volatile var cutK: List<Range>? = null
    @Volatile var env: Env? = null
    private var pcm16: ShortArray? = null
    private var pcm16Len = 0
    private var pcmFull = false
    private var pcmJob: Deferred<Unit>? = null
    private var wantLen = 0.0

    /* ---------------- transcript / captions ---------------- */
    @Volatile final override var cues: List<Cue> = emptyList(); private set
    @Volatile var segs: List<Seg> = emptyList(); private set
    @Volatile var blIv: List<Iv> = emptyList(); private set
    private var approx = false
    private var asrW: List<Iv> = emptyList()
    private var blT: List<List<Regex>> = emptyList()

    /* ---------------- B-roll ---------------- */
    @Volatile final override var broll: List<BrollItem> = emptyList(); private set
    var brPool: List<BrAsset> = emptyList(); private set
    private val brAssets = HashMap<String, BrAsset>()
    private var brSeq = 1000
    private var assetSeq = 1
    var brRules by mutableStateOf(App.prefs.brRules)
    var brTargets by mutableStateOf(listOf<String>())
    private var brBusy = false; private var brAgain = false

    /* ---------------- music / SFX ---------------- */
    private var bgmList: List<Track> = emptyList()
    private var sfxList: List<Track> = emptyList()
    private var transList: List<Track> = emptyList()
    @Volatile var sfxT: List<SfxPlacement> = emptyList(); private set
    private var bgmChoice: String? = null
    private var hookChoice: String? = null
    private var keepPick = false
    private var trSeed = Random.nextInt(1_000_000_000)
    private val anCache = HashMap<String, Track>()
    private var libJob: Deferred<LibListing>? = null
    private class AutoOn { var bgm = false; var sfx = false; var br = false }
    private val autoOn = AutoOn()
    var bselOptions by mutableStateOf(listOf<String>())

    /* ---------------- UI state ---------------- */
    var sn by mutableStateOf(SN_DEFAULT)
    var hkn by mutableStateOf(HKN_DEFAULT)
    var asrn by mutableStateOf(ASRN_DEFAULT)
    var trn by mutableStateOf("")
    var bwn by mutableStateOf("")
    var brn by mutableStateOf(BRN_DEFAULT)
    var libn by mutableStateOf("Looking for your library…")
    var stat by mutableStateOf("Load a video to begin.")
    var rep by mutableStateOf("No edit yet.")
    var hooks by mutableStateOf(listOf<HookItem>())
    var hookSel by mutableIntStateOf(-1)
    var rev by mutableIntStateOf(0)
    var phRel by mutableDoubleStateOf(0.0)
    var playing by mutableStateOf(false); private set
    var task by mutableStateOf<TaskUi?>(null); private set
    val busy = mutableStateMapOf<String, Boolean>()
    var export by mutableStateOf<ExportUi?>(null)
    var needModel by mutableStateOf(false)
    @Volatile private var exportCancel = false
    private var lastRes = 1080; private var lastFps = 30

    init {
        s.bw = App.prefs.blurWords
        blCompile()
        viewModelScope.launch {
            try {
                val L = withContext(Dispatchers.IO) { Library.list(ctx) }
                fillBsel(L.bgm.map { it.name })
                brTargets = L.broll.map { BrMatch.key(it.name).joinToString(" ") }.filter { it.isNotEmpty() }.distinct()
                libn = "Library connected: found ${L.bgm.size} music track(s), ${L.sfx.size} hook SFX, ${L.trans.size} transition SFX and ${L.broll.size} B-roll clip(s). Press Auto BGM or Auto Hook SFX and the editor scans, scores and applies them for you."
            } catch (e: Exception) { srvDown(e) }
        }
    }

    /* ================= timeline maths ================= */
    fun t0() = s.st
    override fun clipLen(): Double {
        cutK?.let { val l = it.last(); return l.o + l.b - l.a }
        return max(1.0, min(if (s.ln > 0) s.ln else 30.0, dur - t0()))
    }
    fun ranges(): List<Range> = cutK ?: listOf(Range(t0(), t0() + clipLen(), 0.0))
    fun srcLen(): Double = cutK?.let { it.last().b - t0() } ?: clipLen()
    override fun otime(ts: Double) = Core.otime(ranges(), ts)
    fun stime(o: Double) = Core.stime(ranges(), o)

    /* ================= task / status toast ================= */
    private var hideTask: Runnable? = null
    private fun showTask(t: TaskUi, hideAfter: Long) {
        hideTask?.let { main.removeCallbacks(it) }
        task = t
        if (hideAfter > 0) { val r = Runnable { task = null }; hideTask = r; main.postDelayed(r, hideAfter) }
    }
    fun taskBegin(t: String, btn: String? = null) { btn?.let { busy[it] = true }; showTask(TaskUi("$t…", 0, null), 0) }
    fun taskMsg(t: String, p: Float? = null) {
        post {
            val cur = task ?: return@post
            if (cur.state != 0) return@post
            val m = Regex("(\\d+)%").find(t)
            showTask(TaskUi(t, 0, p ?: m?.groupValues?.get(1)?.toFloatOrNull()?.div(100f)), 0)
        }
    }
    fun taskEnd(t: String, btn: String? = null) { btn?.let { busy.remove(it) }; showTask(TaskUi("✓ $t", 1, 1f), 2400) }
    fun taskFail(t: String, btn: String? = null) { btn?.let { busy.remove(it) }; showTask(TaskUi("⚠ $t", 2, null), 4500) }
    fun taskClose(btn: String? = null) { btn?.let { busy.remove(it) }; if (task?.state == 0) task = null }

    /** web: wrapTask() */
    private fun launchTask(title: String, btn: String, done: String, block: suspend () -> Boolean) = viewModelScope.launch {
        taskBegin(title, btn)
        try {
            val ok = block()
            if (!ok) taskFail("$title failed · see the note in the panel", btn) else taskEnd("Done · $done", btn)
        } catch (e: CancellationException) { taskClose(btn); throw e }
        catch (e: Exception) { taskFail("$title failed", btn); stat = e.message ?: e.toString() }
    }

    fun bump() { rev++; report(); preview.requestStill() }
    fun onPlayState(p: Boolean) { playing = p }

    /* ================= 1 · source video ================= */
    fun pickSource(uri: Uri) = viewModelScope.launch {
        preview.stop()
        taskBegin("Loading video")
        try {
            val info = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try {
                    MediaUtil.setSource(r, ctx, uri)
                    val d = (r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L) / 1000.0
                    var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                    var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                    val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                    if (rot % 180 != 0) { val t = w; w = h; h = t }
                    Triple(d, w, h)
                } finally { r.release() }
            }
            if (info.first <= 0 || info.second <= 0) throw IOException("not a video")
            pcmJob?.cancel(); pcmJob = null; pcm16 = null; pcm16Len = 0; env = null
            srcUri = uri; dur = info.first; srcName = displayName(uri)
            cutK = null; s.cut = false
            s.ln = min(30.0, floor(dur)); wantLen = s.ln
            phRel = 0.0
            preview.resetSource()
            stat = "$srcName · ${"%.1f".format(dur)}s · ${info.second}×${info.third}"
            taskEnd("Done · video loaded")
            if (s.tr.isNotBlank()) build() else bump()
            queueAuto()
            startPcm() // analyse the audio in the background (silence cut, captions snap, ASR)
            if (ModelManager(ctx).isReady()) viewModelScope.launch(Dispatchers.Default) { runCatching { ParakeetEngine.get(ctx) } } // warm up the model
        } catch (e: Exception) { taskFail("Could not load this video") }
    }

    private fun displayName(uri: Uri): String = try {
        ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
    } catch (e: Exception) { null } ?: (uri.lastPathSegment ?: "video")

    /** One pass over the source audio: 16 kHz mono copy (for ASR) + 20 ms loudness envelope. */
    private fun startPcm(): Deferred<Unit> {
        pcmJob?.let { return it }
        val uri = srcUri ?: throw IOException("Load a source video first.")
        val job = viewModelScope.async(Dispatchers.Default) {
            var buf = ShortArray(16000 * 120); var n = 0
            val db = FloatList(); var acc = 0.0; var cnt = 0
            var total = 0L
            AudioDecoder.decodeStream(ctx, uri, 0.0, 1e9, 16000, 1, { !isActive }, {}) { v ->
                if (n < PCM_CAP) {
                    if (n == buf.size) buf = buf.copyOf(min(PCM_CAP, buf.size * 2))
                    buf[n++] = (v * 32767f).roundToInt().coerceIn(-32768, 32767).toShort()
                }
                total++
                acc += v * v; cnt++
                if (cnt == 320) { db.add(Env.rmsDb(acc, 320)); acc = 0.0; cnt = 0 }
            }
            if (srcUri == uri) {
                pcm16 = buf; pcm16Len = n; pcmFull = total <= PCM_CAP
                env = Env.fromDb(db.toArray(), 0.02).also { it.thr = it.sorted90 - s.sth.toFloat() }
            }
        }
        pcmJob = job
        return job
    }

    suspend fun getEnv(): Env? {
        if (srcUri == null) return null
        return try { startPcm().await(); env?.also { it.thr = it.sorted90 - s.sth.toFloat() } }
        catch (e: CancellationException) { throw e } catch (e: Exception) { null }
    }

    /** 16 kHz mono PCM of source [a, b). */
    private suspend fun pcmRange(a: Double, b: Double): FloatArray {
        val uri = srcUri ?: return FloatArray(0)
        try { startPcm().await() } catch (e: CancellationException) { throw e } catch (e: Exception) {}
        val p = pcm16
        val from = max(0, (a * 16000).toInt())
        var to = (b * 16000).toInt()
        if (p != null && (to <= pcm16Len || pcmFull)) {
            to = min(to, pcm16Len)
            if (to <= from) return FloatArray(0)
            return FloatArray(to - from) { p[from + it] / 32768f }
        }
        return withContext(Dispatchers.Default) { AudioDecoder.decode(ctx, uri, a, b, 16000, 1).data }
    }

    /* ---------- silence cut ---------- */
    private var rangeJob: Job? = null
    /** start / length / cut settings changed (debounced) */
    fun rangeChanged(lengthEdited: Boolean = false) {
        if (lengthEdited) wantLen = if (s.ln > 0) s.ln else 30.0
        rangeJob?.cancel()
        rangeJob = viewModelScope.launch { delay(300); recut(); build() }
    }

    suspend fun recut() {
        if (!s.cut) { cutK = null; sn = SN_DEFAULT; return }
        taskBegin("Analyzing audio for silence")
        sn = "Analyzing audio..."
        if (srcUri == null) { cutK = null; sn = "Load a source video first."; s.cut = false; taskClose(); return }
        val E = getEnv()
        if (E == null) { cutK = null; sn = "Silence analysis failed: could not read the audio of this video."; taskFail("Silence cut failed"); return }
        val want = if (wantLen > 0) wantLen else s.ln
        val st = t0()
        val R = withContext(Dispatchers.Default) { Core.makeRanges(E.db, E.step, st, want, s.sth, s.sgp, min(if (dur > 0) dur else 1e9, E.lengthSec)) }
        if (R == null) { cutK = null; sn = "No speech found after the start time."; taskClose(); return }
        cutK = R
        val last = R.last(); val out = last.o + last.b - last.a; val removed = (last.b - st) - out
        sn = "Cut ${max(0, R.size - 1)} pauses" + (if (R[0].a > st + 0.05) " + leading silence" else "") + " · removed ${"%.1f".format(removed)}s · final length ${"%.1f".format(out)}s" +
            (if (out < want - 0.3) " (video ends before ${want.toInt()}s)" else "")
        taskEnd("Done · silence removed")
    }

    /* ================= 2 · transcript ================= */
    private var buildJob: Job? = null
    fun transcriptEdited() { buildJob?.cancel(); buildJob = viewModelScope.launch { delay(250); build() } }

    fun blCompile() {
        blT = Core.blCompile(s.bw)
        bwn = "${blT.size} words/phrases in the blur list."
        App.prefs.blurWords = s.bw
    }
    fun blurListEdited() { buildJob?.cancel(); buildJob = viewModelScope.launch { delay(300); blCompile(); build() } }
    fun resetBlurList() { s.bw = Core.BL_DEFAULT.joinToString("\n"); blCompile(); build() }

    fun build() {
        val parsed = Core.parseTr(s.tr, t0(), srcLen())
        segs = parsed.segs; approx = parsed.approx
        val n = s.wn.coerceAtLeast(1)
        var nBl = 0
        val bl = ArrayList<Iv>()
        val pad = if (approx || asrW.isEmpty()) 0.12 else 0.05
        val cs = ArrayList<Cue>()
        val E = env
        for (sg in segs) {
            val wt = Core.wordTimes(sg, asrW, E)
            nBl += Core.markBlur(wt, s.bon, blT)
            if (s.bbp) wt.filter { it.bl }.forEach { bl.add(Iv(max(0.0, it.s - pad), it.e + pad)) }
            var i = 0
            while (i < wt.size) { val g = wt.subList(i, min(i + n, wt.size)).toList(); cs.add(Cue(g.first().s, g.last().e, g.map { it.t }, g)); i += n }
        }
        bl.sortBy { it.s }
        val merged = ArrayList<Iv>()
        for (x in bl) { val l = merged.lastOrNull(); if (l != null && x.s <= l.e + 0.02) l.e = max(l.e, x.e) else merged.add(Iv(x.s, x.e)) }
        Core.fixCues(cs)
        cues = cs; blIv = merged
        trn = if (segs.isEmpty()) "" else "${segs.size} segments, ${cs.size} caption cues" +
            (if (approx) " · timings approximate (estimated)" else if (asrW.isNotEmpty()) " · word-level timing" else "") +
            (if (nBl > 0) " · $nBl word${if (nBl > 1) "s" else ""} blurred" else "")
        bump(); queueAuto()
    }

    fun loadTranscriptFile(uri: Uri) = viewModelScope.launch {
        val t = withContext(Dispatchers.IO) { runCatching { ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull() }
        if (t != null) { s.tr = t; build() }
    }

    private suspend fun engine(note: (String) -> Unit): ParakeetEngine {
        if (!ModelManager(ctx).isReady()) { needModel = true; throw IOException("Download the Parakeet model first (one time, about 670 MB).") }
        if (!ParakeetEngine.isLoaded) note("Loading Parakeet from phone storage…")
        val e = withContext(Dispatchers.Default) { ParakeetEngine.get(ctx) }
        note("Parakeet model loaded from phone storage.")
        return e
    }

    fun transcribe() = viewModelScope.launch {
        if (srcUri == null) { asrn = "Load a source video first."; return@launch }
        taskBegin("Transcribing", "asr")
        val note = { t: String -> asrn = t; taskMsg(t) }
        try {
            note("Reading audio from video...")
            val a = t0(); val L = srcLen()
            val pcm = pcmRange(a, a + L)
            if (pcm.isEmpty()) { note("Start time is past the end of the video."); taskClose("asr"); return@launch }
            val eng = engine(note)
            note("Transcribing ${L.roundToInt()}s of audio with Parakeet...")
            val words = withContext(Dispatchers.Default) { eng.transcribe(pcm, { p -> post { note("Transcribing with Parakeet… ${(p * 100).roundToInt()}%") } }) }
            val w = Core.wseg(words.map { Triple(it.text, it.s, it.e) }, a)
            asrW = w.asrW
            if (w.segs.isEmpty()) { note("No speech found in that range."); taskClose("asr"); return@launch }
            s.tr = Core.toSrt(w.segs)
            getEnv()
            build()
            asrn = "Done: ${w.segs.size} segments. Edit the text box to fix any wrong words."
            taskEnd("Done · transcript ready", "asr")
        } catch (e: CancellationException) { taskClose("asr"); throw e }
        catch (e: Exception) { asrn = "Failed: " + (e.message ?: e.toString()); taskFail(asrn, "asr") }
    }

    /* ---------- smart start: hook finder ---------- */
    fun findHooks() = viewModelScope.launch {
        if (srcUri == null) { hkn = "Load a source video first."; return@launch }
        taskBegin("Finding hook lines", "hook")
        val note = { t: String -> hkn = t; taskMsg(t) }
        try {
            note("Reading audio from video...")
            val pcm = pcmRange(0.0, 180.0)
            if (pcm.isEmpty()) { note("Could not read audio."); taskClose("hook"); return@launch }
            val eng = engine(note)
            note("Listening for the engaging part with Parakeet... this can take a minute.")
            val words = withContext(Dispatchers.Default) { eng.transcribe(pcm, { p -> post { note("Listening with Parakeet… ${(p * 100).roundToInt()}%") } }) }
            val w = Core.wseg(words.map { Triple(it.text, it.s, it.e) }, 0.0)
            asrW = w.asrW
            val sg = w.segs
            if (sg.isEmpty()) { note("No speech found in the first 3 minutes."); taskClose("hook"); return@launch }
            s.tr = Core.toSrt(sg)
            val want = if (wantLen > 0) wantLen else s.ln
            val d = if (dur > 0) dur else pcm.size / 16000.0
            val fit = sg.filter { it.s + want <= d + 0.5 }
            val pool = fit.ifEmpty { sg }
            val ranked = pool.map { it to Core.hookScore(it.text, sg.indexOf(it)) }
                .sortedWith(compareByDescending<Pair<Seg, Double>> { it.second }.thenBy { it.first.s }).take(3).map { it.first }
            val top = ranked.toSet()
            hooks = (ranked.mapIndexed { i, x -> HookItem(x, if (i == 0) "Best" else "#${i + 1}") } + sg.filter { it !in top }.map { HookItem(it, null) }).take(60)
            hookSel = 0
            applyStartNow(ranked[0])
            taskEnd("Done · hook line found", "hook")
        } catch (e: CancellationException) { taskClose("hook"); throw e }
        catch (e: Exception) { hkn = "Failed: " + (e.message ?: e.toString()); taskFail(hkn, "hook") }
    }

    fun applyStart(i: Int) { hookSel = i; hooks.getOrNull(i)?.let { h -> viewModelScope.launch { applyStartNow(h.seg) } } }

    private suspend fun applyStartNow(c: Seg) {
        val want = if (wantLen > 0) wantLen else s.ln
        var st = max(0.0, c.s - 0.2); var shifted = false
        if (dur > 0 && st + want > dur) { st = max(0.0, dur - want); shifted = true }
        st = (st * 10).roundToInt() / 10.0
        s.st = st
        val len = if (dur > 0) max(1.0, min(want, floor((dur - st) * 10) / 10)) else want
        s.ln = len
        phRel = 0.0
        hkn = "Clip: ${"%.1f".format(st)}s → ${"%.1f".format(st + len)}s (${"%.1f".format(len)}s)" +
            (if (shifted) " · not enough video after that line, so the start was moved earlier to keep your length" else "") + ". \"${c.text.take(60)}\""
        recut(); build()
    }

    /* ================= 4 · B-roll ================= */
    private fun brMax() = if (s.brmax > 0) s.brmax else 2.0

    fun addManualBroll(uris: List<Uri>) = viewModelScope.launch {
        val got = withContext(Dispatchers.IO) {
            uris.mapNotNull { u ->
                runCatching { ctx.contentResolver.takePersistableUriPermission(u, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                BrAsset.load(ctx, assetSeq++, displayName(u).take(40), u, ctx.contentResolver.getType(u))
            }
        }
        brPool = brPool + got
        stat = "${brPool.size} B-roll asset(s) loaded."
    }

    /** web: autoPlace() — deterministic round-robin over manually added files */
    fun autoPlace() {
        if (segs.isEmpty() || brPool.isEmpty()) { stat = "Need a transcript and B-roll first."; return }
        val L = clipLen(); val pool = brPool; var k = 0; var last = -1
        val out = ArrayList<BrollItem>()
        val inClip = segs.filter { otime(it.e) > otime(it.s) && otime(it.s) < L }
        inClip.forEachIndexed { i, sg ->
            if (i % 2 == 0) return@forEachIndexed
            val st = otime(sg.s); val d = min(brMax(), max(1.5, sg.e - sg.s))
            if (st + d > L) return@forEachIndexed
            var b = pool[k % pool.size]
            if (pool.size > 1 && b.id == last) { k++; b = pool[k % pool.size] }
            k++; last = b.id
            out.add(BrollItem(brSeq++, b, st, d, false))
        }
        broll = out
        bump()
        if (sfxList.isNotEmpty() && s.sfxcut) viewModelScope.launch { placeSfx(false) }
    }

    fun clearBroll() { broll = emptyList(); brPool = emptyList(); autoOn.br = false; bump() }
    fun removeBroll(id: Int) { broll = broll.filter { it.id != id }; bump() }
    fun removeSfx(i: Int) { sfxT = sfxT.filterIndexed { k, _ -> k != i }; bump() }

    fun brMaxChanged() {
        val m = brMax()
        broll = broll.map { if (it.dur > m) it.copy(dur = m) else it }
        bump()
        if (autoOn.br) viewModelScope.launch { autoBrollS(true) }
    }

    fun addRule(words: String, target: String): Boolean {
        val w = words.split(Regex("[,;\\n]+")).map { it.trim().lowercase() }.filter { it.isNotEmpty() }
        val t = target.trim()
        if (w.isEmpty() || t.isEmpty()) { brn = "Type the caption word(s) and the B-roll name, then press Add word rule."; return false }
        brRules = brRules + BrRule(w, t); App.prefs.brRules = brRules
        if (autoOn.br) viewModelScope.launch { autoBrollS(true) } else brn = "Rule added. Press \"Auto B-roll from captions\" to apply it."
        return true
    }
    fun removeRule(i: Int) {
        brRules = brRules.filterIndexed { k, _ -> k != i }; App.prefs.brRules = brRules
        if (autoOn.br) viewModelScope.launch { autoBrollS(true) }
    }

    fun autoBroll() = viewModelScope.launch {
        Library.invalidate()
        taskBegin("Auto B-roll", "brauto")
        val placed = try { autoBrollS(false) } catch (e: CancellationException) { taskClose("brauto"); throw e } catch (e: Exception) { brn = e.message ?: e.toString(); false }
        if (placed) taskEnd("Done · B-roll placed", "brauto") else taskFail("Auto B-roll failed · see the note in the panel", "brauto")
    }

    private suspend fun autoBrollS(fromQueue: Boolean): Boolean {
        if (brBusy) { brAgain = true; return true }
        brBusy = true
        try {
            if (cues.isEmpty()) { brn = "Need captions first: use Auto-transcribe or paste a transcript, then press this again."; return false }
            brn = "Scanning the B-roll folder…"
            val lib = try { withContext(Dispatchers.IO) { Library.list(ctx) } } catch (e: Exception) {
                brn = "Could not read the B-roll list (${e.message}). Check Settings → Library source."; return false
            }
            val files = lib.broll
            if (files.isEmpty()) { brn = "No B-roll found. Put your clips in the \"${lib.brollFolder}\" folder of your library (e.g. blood_01.mp4, heart1.mp4)."; return false }
            autoOn.br = true
            brTargets = files.map { BrMatch.key(it.name).joinToString(" ") }.filter { it.isNotEmpty() }.distinct()
            val idx = BrMatch.index(files, brRules)
            val W = cues.flatMap { it.wt }.sortedBy { it.s }
            val ev = BrMatch.events(idx, W, ranges()) { otime(it) }
            val need = LinkedHashSet<BrFile>(); ev.forEach { e -> need.addAll(e.k.files) }
            brn = "Loading ${need.size} matching clip(s)…"
            withContext(Dispatchers.IO) {
                for (f in need) {
                    val key = f.url + "|" + f.version
                    f.asset = brAssets[key] ?: runCatching {
                        val u = Library.resolve(ctx, f)
                        BrAsset.load(ctx, assetSeq++, f.name, u)
                    }.getOrNull()?.also { brAssets[key] = it }
                }
            }
            val plan = BrMatch.plan(ev, brMax(), clipLen())
            broll = plan.map { BrollItem(brSeq++, it.a, it.start, it.dur, true) }
            bump()
            val cnt = LinkedHashMap<String, Int>(); plan.forEach { cnt[it.k.key] = (cnt[it.k.key] ?: 0) + 1 }
            val used = cnt.entries.joinToString(", ") { "${it.key} ×${it.value}" }
            val all = idx.keys.keys.joinToString(", ")
            val miss = if (idx.missing.isNotEmpty()) " No clip found for rule target: " + idx.missing.joinToString(", ") + "." else ""
            brn = (if (plan.isNotEmpty()) "Placed ${plan.size} clip(s), max ${brMax()}s each: $used." else "No caption word matched a B-roll filename.") + " Keywords available: $all.$miss"
            stat = if (plan.isNotEmpty()) "${plan.size} B-roll clip(s) inserted from captions." else "No keyword matches in the captions."
            if (s.sfxcut) {
                try { val LL = withContext(Dispatchers.IO) { Library.list(ctx) }; if (LL.trans.isNotEmpty() || transList.isNotEmpty()) loadLibrary() } catch (e: Exception) {}
                if (autoOn.sfx && sfxList.isNotEmpty()) { if (!fromQueue) placeSfx(false) }
                else { val nt = placeTrans(); bump(); if (nt > 0) stat += " + $nt transition sound(s)." }
            }
            return true
        } finally {
            brBusy = false
            if (brAgain) { brAgain = false; viewModelScope.launch { autoBrollS(true) } }
        }
    }

    /* ================= 5 · music + hook SFX ================= */
    private fun libNote(t: String) { libn = t; taskMsg(t) }
    private fun srvDown(e: Exception) {
        libNote("Could not read your library (${e.message ?: e}). Open Settings → Library source: GitHub repo, website address or a folder on this phone.")
    }
    private fun fillBsel(names: List<String>) {
        bselOptions = names
        if (s.bsel != "auto" && s.bsel !in names) s.bsel = "auto"
    }

    private suspend fun loadLibrary(): LibListing {
        libJob?.let { if (it.isActive) return it.await() }
        val job = viewModelScope.async {
            val L = withContext(Dispatchers.IO) { Library.list(ctx) }
            suspend fun get(f: BrFile, kind: Char, i: Int, n: Int): Track? {
                val key = "$kind|${f.url}|${f.version}"
                anCache[key]?.let { return it }
                libNote("Analysing " + (if (kind == 'b') "music " else "SFX ") + "${i + 1}/$n…")
                return try { withContext(Dispatchers.IO) { Library.analyse(ctx, f, kind) }.also { anCache[key] = it } } catch (e: Exception) { android.util.Log.w("Library", f.name, e); null }
            }
            val nb = L.bgm.mapIndexedNotNull { i, f -> get(f, 'b', i, L.bgm.size) }.toMutableList()
            val ns = L.sfx.mapIndexedNotNull { i, f -> get(f, 's', i, L.sfx.size) }
            val nt = L.trans.mapIndexedNotNull { i, f -> get(f, 't', i, L.trans.size) }
            val len = clipLen(); nb.forEach { Library.scoreBgm(it, len) }; nb.sortByDescending { it.sc }
            bgmList = nb; sfxList = ns; transList = nt
            fillBsel(nb.map { it.name })
            libNote("${nb.size} music track(s), ${ns.size} hook SFX, ${nt.size} transition SFX ready. Folders are re-scanned each time you use Auto BGM / Auto Hook SFX.")
            L
        }
        libJob = job
        return job.await()
    }

    fun bgmPick(): Track? {
        if (bgmList.isEmpty()) return null
        val v = s.bsel
        var p = bgmList.find { it.name == v }
        if (p == null && bgmChoice != null) p = bgmList.find { it.name == bgmChoice }
        return p ?: bgmList[0]
    }

    private suspend fun autoBgmS(): Boolean {
        autoOn.bgm = true; s.bsel = "auto"
        try { loadLibrary() } catch (e: CancellationException) { throw e } catch (e: Exception) { if (bgmList.isEmpty()) { autoOn.bgm = false; srvDown(e); return false } }
        if (bgmList.isEmpty()) { autoOn.bgm = false; libNote("No audio files found in the \"bgm\" folder."); return false }
        val L = clipLen(); bgmList.forEach { Library.scoreBgm(it, L) }; bgmList = bgmList.sortedByDescending { it.sc }
        if (!keepPick || bgmChoice == null || bgmList.none { it.name == bgmChoice }) bgmChoice = Library.pickRand(bgmList, bgmChoice).name
        val P = bgmPick()!!
        Library.scoreBgm(P, L)
        bump(); restartPreview()
        stat = "Auto BGM (random pick): \"${P.name}\" (starting ${"%.1f".format(P.off)}s into the track, ducked under speech). Press Auto BGM again for a different one."
        return true
    }
    fun autoBgm() { Library.invalidate(); launchTask("Auto BGM", "bgmbtn", "music applied") { autoBgmS() } }

    private suspend fun autoHookS(): Boolean {
        autoOn.sfx = true
        try { loadLibrary() } catch (e: CancellationException) { throw e } catch (e: Exception) { if (sfxList.isEmpty()) { autoOn.sfx = false; srvDown(e); return false } }
        if (sfxList.isEmpty()) { autoOn.sfx = false; libNote("No audio files found in the \"best hook\" folder."); return false }
        placeSfx(true)
        stat += " Press Auto Hook SFX again for a different one. Press Preview to hear it."
        return true
    }
    fun autoHook() { Library.invalidate(); launchTask("Auto Hook SFX", "sfxbtn", "hook SFX applied") { autoHookS() } }

    fun onBselChange(v: String) = viewModelScope.launch {
        if (v == "auto") { autoBgm(); return@launch }
        autoOn.bgm = false
        if (bgmList.none { it.name == v }) try { loadLibrary() } catch (e: Exception) { srvDown(e) }
        s.bsel = v
        bump(); restartPreview()
    }

    fun sfxcutChanged() { if (autoOn.sfx) viewModelScope.launch { placeSfx(false) } else { placeTrans(); bump() } }

    private fun addSfx(t: Track, hit: Double, v: Double, md: Double = 4.0, tr: Boolean = false): SfxPlacement {
        val off = max(0.0, t.pk - hit)
        return SfxPlacement(t, max(0.0, hit - t.pk), off, hit, v, min(t.dur - off, md), tr)
    }

    /** transition sounds at the start of B-roll clips: random, ~70% of clips, never the same file twice in a row */
    private fun placeTrans(): Int {
        val keepList = sfxT.filter { !it.tr }
        if (!s.sfxcut || transList.isEmpty()) { sfxT = keepList; return 0 }
        val R = Mulberry(trSeed)
        val bs = broll.filter { it.dur > 0 }.sortedBy { it.start }
        var last = -1; var n = 0
        val add = ArrayList<SfxPlacement>()
        for (b in bs) {
            val keep = R.next(); val pk = R.next()
            if (keep > 0.7) continue
            var i = floor(pk * transList.size).toInt().coerceIn(0, transList.size - 1)
            if (transList.size > 1 && i == last) i = (i + 1 + floor(R.next() * (transList.size - 1)).toInt()) % transList.size
            last = i; add.add(addSfx(transList[i], b.start, 0.7, 2.5, true)); n++
        }
        sfxT = keepList + add
        return n
    }

    private suspend fun placeSfx(reroll: Boolean) {
        if (sfxList.isEmpty()) { stat = "Set up your library first (Settings → Library source)."; return }
        val E = getEnv()
        var hit = 0.0
        val c0 = cues.firstOrNull()
        if (cutK == null && E != null) {
            var t = t0(); val end = min(t0() + 10, E.lengthSec)
            while (t < end && !E.loudAt(t)) t += E.step
            hit = max(0.0, t - t0() - 0.05)
        } else if (c0 != null) hit = max(0.0, otime(c0.s) - 0.05)
        if (reroll) trSeed = Random.nextInt(1_000_000_000)
        if (reroll || hookChoice == null || sfxList.none { it.name == hookChoice }) hookChoice = Library.pickRand(sfxList, hookChoice).name
        val hk = sfxList.first { it.name == hookChoice }
        val list = ArrayList<SfxPlacement>()
        list.add(addSfx(hk, hit, 1.0))
        if (s.sfxcut && transList.isEmpty()) {
            val T = sfxList.filter { it !== hk }.sortedByDescending { it.ts }
            if (T.isNotEmpty()) broll.filter { it.dur > 0 }.sortedBy { it.start }.forEachIndexed { i, b -> list.add(addSfx(T[i % T.size], b.start, 0.6)) }
        }
        sfxT = list
        val nt = placeTrans()
        bump()
        stat = "Hook SFX \"${hk.name}\" lands on the first spoken word at ${"%.2f".format(hit)}s." + (if (nt > 0) " + $nt transition sound(s) on B-roll." else "")
    }

    /** when start, length, silence cut or transcript change, redo whatever was switched to Auto */
    private var qJob: Job? = null
    private fun queueAuto() {
        if (!autoOn.bgm && !autoOn.sfx && !autoOn.br) return
        qJob?.cancel()
        qJob = viewModelScope.launch {
            delay(200)
            if (autoOn.br) autoBrollS(true)
            if (autoOn.bgm) { keepPick = true; try { autoBgmS() } finally { keepPick = false } }
            if (autoOn.sfx) placeSfx(false)
        }
    }

    /* ================= preview ================= */
    fun togglePlay() { if (playing || preview.playing) preview.stop() else preview.play() }
    private fun restartPreview() {
        if (!preview.playing) return
        preview.stop()
        main.postDelayed({ preview.play() }, 300)
    }
    fun seekFraction(f: Double) { if (!hasVideo) return; phRel = (f.coerceIn(0.0, 1.0) * clipLen()); preview.requestStill() }

    /** exact export mix, used by the preview player (called on its own thread) */
    fun mixBlocking(cancel: () -> Boolean): FloatArray = runBlocking {
        val E = getEnv()
        val pick = bgmPick()
        AudioMixer.mix(ctx, srcUri!!, ranges(), clipLen(), blIv, { otime(it) }, { stime(it) }, E, pick, s.bv, sfxT, cancel)
    }

    /* ================= export ================= */
    fun openExport() {
        if (!hasVideo) { taskFail("Load a source video first"); return }
        preview.stop()
        export = ExportUi(0, lastRes, lastFps)
    }
    fun exportSummary(res: Int, fps: Int): String {
        val br = (if (res == 2160) 45e6 else 14e6) * (if (fps > 30) 1.4 else 1.0)
        val L = clipLen(); val mb = (br + 192e3) * L / 8e6
        val wh = if (res == 2160) "2160×3840" else "1080×1920"
        return "$wh · $fps fps · ${"%.1f".format(L)}s · about ${mb.roundToInt()} MB · MP4 (H.264 + AAC)"
    }
    fun setExportOpt(res: Int? = null, fps: Int? = null) { export = export?.copy(res = res ?: export!!.res, fps = fps ?: export!!.fps) }
    fun closeExport() { if (export?.stage == 1) return; export = null }
    fun cancelExport() { exportCancel = true }

    fun runExport() {
        val ui = export ?: return
        lastRes = ui.res; lastFps = ui.fps
        exportCancel = false
        val res = ui.res; val fps = ui.fps
        val w = if (res == 2160) 2160 else 1080; val h = if (res == 2160) 3840 else 1920; val S = if (res == 2160) 2f else 1f
        val bitrate = ((if (res == 2160) 45e6 else 14e6) * (if (fps > 30) 1.4 else 1.0)).toInt()
        val name = "dweis-edit-" + (if (res == 2160) "4k" else "1080p") + "-${fps}fps-${System.currentTimeMillis() / 1000}.mp4"
        export = ui.copy(stage = 1, pct = 0f, title = "Exporting ${w}×$h…", note = "Checking this device…")
        fun upd(p: Float?, n: String?) = post { export = export?.let { e -> if (e.stage != 1) e else e.copy(pct = p ?: e.pct, note = n ?: e.note) } }
        viewModelScope.launch(Dispatchers.Default) {
            var fs: FrameSource? = null
            val bf = BrollFrames(ctx)
            try {
                if (!Exporter.canEncode(w, h, fps)) throw IOException("This phone cannot encode ${w}×$h at $fps fps. Try Full HD or 30 fps.")
                upd(0.02f, "Mixing audio (speech, music, SFX)…")
                val L = clipLen(); val N = max(1, (L * fps).roundToInt())
                val audio = AudioMixer.mix(ctx, srcUri!!, ranges(), L, blIv, { otime(it) }, { stime(it) }, getEnv(), bgmPick(), s.bv, sfxT) { exportCancel }
                upd(0.10f, "Preparing fast video reader…")
                val src = FrameSource.open(ctx, srcUri!!)
                fs = src
                val rnd = Renderer(this@EditorViewModel)
                val out = File(File(ctx.cacheDir, "exports").apply { mkdirs() }, name)
                val t1 = System.currentTimeMillis()
                Exporter(out, w, h, fps, bitrate).run(N, audio, { exportCancel }, { i ->
                    if (i % 4 == 0) {
                        val el = (System.currentTimeMillis() - t1) / 1000.0; val eta = el / (i + 1) * (N - i - 1)
                        upd(0.10f + 0.86f * i / N, "Frame ${i + 1} of $N · about " + (if (eta > 60) "${Math.ceil(eta / 60).toInt()} min" else "${Math.ceil(eta).toInt()} s") + " left")
                    }
                }) { c, i ->
                    val rel = min(i.toDouble() / fps, L - 0.001)
                    val ts = stime(rel)
                    val vf = src.frameAt(ts)
                    rnd.draw(c, S, ts, vf) { b, local -> runCatching { bf.frame(b, local) }.getOrNull() }
                }
                upd(0.97f, "Saving to your gallery (Movies/AutoClipper)…")
                val uri = saveToGallery(out, name)
                post { export = export?.copy(stage = 2, pct = 1f, title = "✓ Done · export complete", note = "Saved to Movies/AutoClipper/$name", outUri = uri, outName = name); stat = "Exported $name" }
            } catch (e: Exception) {
                val msg = if (e is Exporter.Cancelled || exportCancel) "Cancelled." else (e.message ?: e.toString())
                android.util.Log.e("Export", "failed", e)
                post { export = export?.copy(stage = 3, title = "Export stopped", note = msg) }
            } finally { runCatching { fs?.close() }; bf.close() }
        }
    }

    private fun saveToGallery(f: File, name: String): Uri {
        val cv = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, name)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AutoClipper")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val cr = ctx.contentResolver
        val uri = cr.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv) ?: throw IOException("Could not create the gallery file")
        cr.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o, 1 shl 16) } }
        cr.update(uri, ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }, null, null)
        f.delete()
        return uri
    }

    /* ================= edit report ================= */
    private fun f1(x: Double) = "%.1f".format(x)
    fun report() {
        val L = clipLen()
        val sb = StringBuilder("Source range: ${f1(t0())}s → ${f1(cutK?.last()?.b ?: (t0() + L))}s (${f1(L)}s)\nCaptions: ${cues.size} cues" + (if (approx) " (estimated timings)" else "") + "\n")
        cutK?.let { sb.append("Silence cut: ${it.size - 1} jump cuts, ${f1((it.last().b - t0()) - L)}s removed\n") }
        val used = broll.filter { it.dur > 0 }
        sb.append("B-roll cutaways: ${used.size}\n")
        used.sortedBy { it.start }.forEach { sb.append("  ${f1(it.start)}–${f1(it.start + it.dur)}s  ${it.asset.name}\n") }
        if (segs.isEmpty()) sb.append("Warning: no transcript loaded.\n")
        if (approx) sb.append("Warning: transcript timings were estimated.\n")
        if (s.zm != "none") sb.append("Zoom ${s.zm} ${s.zs.roundToInt()}% over " + (if (s.zw) "the whole clip" else "${f1(s.zd)}s") + "\n")
        bgmPick()?.let { sb.append("Music: ${it.name} (ducks under speech)\n") }
        sfxT.forEach { sb.append("SFX: ${it.s.name} hit at ${"%.2f".format(it.hit)}s\n") }
        rep = sb.toString()
    }

    /** timeline rows for the UI */
    fun sfxRows() = sfxT
    fun bgmName() = bgmPick()?.name

    override fun onCleared() { preview.release(); super.onCleared() }
}
