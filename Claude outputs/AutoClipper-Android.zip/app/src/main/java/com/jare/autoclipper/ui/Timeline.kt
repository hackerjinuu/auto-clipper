package com.jare.autoclipper.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.BoxWithConstraintsScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.jare.autoclipper.editor.EditorViewModel

private val cols = listOf(Color(0xFFB8FF3D), Color(0xFF5EC8FF), Color(0xFFFF8F5E), Color(0xFFD68BFF))

@Composable
private fun Lane(name: String, h: Dp = 26.dp, content: @Composable BoxWithConstraintsScope.() -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Text(name, color = Mut, fontSize = 11.sp, modifier = Modifier.width(56.dp))
        BoxWithConstraints(
            Modifier.weight(1f).height(h).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1D1F23)), content = content
        )
    }
}

@Composable
private fun BoxWithConstraintsScope.Block(start: Double, len: Double, total: Double, color: Color, label: String, dark: Boolean = true, onClick: (() -> Unit)? = null) {
    val x = maxWidth * (start / total).toFloat().coerceIn(0f, 1f)
    val w = (maxWidth * (len / total).toFloat()).coerceAtLeast(2.dp).coerceAtMost(maxWidth - x)
    var m = Modifier.offset(x = x).width(w).fillMaxHeight().padding(vertical = 2.dp).clip(RoundedCornerShape(4.dp)).background(color)
    if (onClick != null) m = m.clickable { onClick() }
    Box(m, contentAlignment = Alignment.CenterStart) {
        Text(label, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Clip, color = if (dark) Color(0xFF111111) else Tx, modifier = Modifier.padding(horizontal = 4.dp))
    }
}

@Composable
fun Timeline(vm: EditorViewModel) {
    @Suppress("UNUSED_VARIABLE") val rev = vm.rev // recompose on edits
    val L = vm.clipLen().coerceAtLeast(0.1)
    val ph = vm.phRel
    Column(Modifier.fillMaxWidth()) {
        Lane("", 18.dp) {
            Box(Modifier.fillMaxWidth().fillMaxHeight().pointerInput(L) {
                detectTapGestures { o -> vm.seekFraction(o.x / size.width.toDouble()) }
            })
            Box(Modifier.offset(x = maxWidth * (ph / L).toFloat().coerceIn(0f, 1f)).width(2.dp).fillMaxHeight().background(Acc))
        }
        Lane("Main") {
            vm.ranges().forEachIndexed { i, r ->
                Block(r.o, r.b - r.a, L, Color(0xFF3A3A3A), if (i == 0) "Speaker · ${"%.1f".format(L)}s" + (if (vm.cutK != null) " (silence cut)" else "") else "", dark = false)
            }
        }
        Lane("B-roll") {
            vm.broll.filter { it.dur > 0 }.forEach { b -> Block(b.start, b.dur, L, cols[b.id % 4], b.asset.name.take(18)) { vm.removeBroll(b.id) } }
        }
        Lane("Captions") {
            vm.cues.forEach { c ->
                val s = vm.otime(c.s); val e = vm.otime(c.e)
                if (e > s) Block(s, e - s, L, Color(0xFF555555), c.words.joinToString(" "), dark = false)
            }
        }
        Lane("SFX") {
            vm.sfxRows().forEachIndexed { i, x -> Block(x.t, maxOf(0.25, x.dur), L, Color(0xFFFF8F5E), x.s.name.take(14)) { vm.removeSfx(i) } }
        }
        Lane("Music") {
            vm.bgmName()?.let { Block(0.0, L, L, Color(0xFF5EC8FF), it) }
        }
        Text("Tap a B-roll or SFX block to remove it. Tap the top bar to move the playhead.", color = Mut, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
