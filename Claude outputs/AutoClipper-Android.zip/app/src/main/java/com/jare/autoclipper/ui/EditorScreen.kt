package com.jare.autoclipper.ui

import android.content.Intent
import android.net.Uri
import android.view.SurfaceView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.jare.autoclipper.editor.EditorViewModel
import com.jare.autoclipper.editor.Settings

@Composable
fun EditorScreen(vm: EditorViewModel, onOpenModel: () -> Unit, onLogout: () -> Unit) {
    val s = vm.s
    var showSettings by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    val pickVideo = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) { runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }; vm.pickSource(u) }
    }
    val pickTr = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? -> if (u != null) vm.loadTranscriptFile(u) }
    val pickBr = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { l: List<Uri> -> if (l.isNotEmpty()) vm.addManualBroll(l) }

    Box(Modifier.fillMaxSize().background(Bg)) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            // ---- header ----
            Row(Modifier.fillMaxWidth().background(Panel).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Jare ", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Tx)
                Text("Enterprise", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Acc)
                Spacer(Modifier.weight(1f))
                Text("⚙ Settings", color = Mut, fontSize = 13.sp, modifier = Modifier.clickable { showSettings = true }.padding(6.dp))
            }
            // ---- preview + transport ----
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.height(300.dp).aspectRatio(9f / 16f).clip(RoundedCornerShape(12.dp)).border(1.dp, Line, RoundedCornerShape(12.dp)).background(Color.Black)) {
                    AndroidView(factory = { c ->
                        SurfaceView(c).apply { holder.setFixedSize(1080, 1920); holder.addCallback(vm.preview) }
                    }, modifier = Modifier.fillMaxSize())
                }
                Column(Modifier.weight(1f).padding(start = 10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AccButton(if (vm.playing) "■ Stop" else "▶ Preview", modifier = Modifier.fillMaxWidth(), enabled = vm.hasVideo || vm.playing) { vm.togglePlay() }
                    PlainButton("Export", Modifier.fillMaxWidth()) { vm.openExport() }
                    PlainButton("Pick video", Modifier.fillMaxWidth()) { pickVideo.launch(arrayOf("video/*")) }
                    Text(vm.stat, color = Mut, fontSize = 11.sp, maxLines = 6)
                    Text("${"%.1f".format(vm.phRel)}s / ${"%.1f".format(vm.clipLen())}s", color = Tx, fontSize = 12.sp)
                }
            }
            // ---- controls ----
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 10.dp)) {
                SectionCard("Timeline") { Timeline(vm) }

                SectionCard("1 · Source video") {
                    Text(if (vm.srcName.isEmpty()) "No video loaded" else vm.srcName, color = Tx, fontSize = 13.sp)
                    PlainButton("Choose video from phone", Modifier.fillMaxWidth().padding(top = 6.dp)) { pickVideo.launch(arrayOf("video/*")) }
                    Row2 {
                        NumField("Start (s)", s.st, Modifier.weight(1f)) { s.st = it.coerceAtLeast(0.0); vm.rangeChanged() }
                        NumField("Max length (s)", s.ln, Modifier.weight(1f)) { s.ln = it.coerceIn(3.0, 90.0); vm.rangeChanged(true) }
                    }
                    CheckRow("✂ Auto-cut silence", s.cut) { s.cut = it; vm.rangeChanged() }
                    LSlider("Cut strength", s.sth, 12.0..40.0, 1.0, onChange = { s.sth = it }, onDone = { vm.rangeChanged() })
                    Choice("Min silence to cut", listOf(0.25 to "0.25 s (tight)", 0.35 to "0.35 s", 0.5 to "0.5 s", 0.8 to "0.8 s (gentle)"), s.sgp, { s.sgp = it; vm.rangeChanged() })
                    Note(vm.sn)
                    AccButton("✨ Find hook lines", vm.busy["hook"] == true, Modifier.fillMaxWidth().padding(top = 8.dp)) { vm.findHooks() }
                    Note(vm.hkn)
                    Column(Modifier.heightIn(max = 260.dp).verticalScroll(rememberScrollState())) {
                        vm.hooks.forEachIndexed { i, h ->
                            val on = i == vm.hookSel
                            Row(
                                Modifier.fillMaxWidth().padding(top = 5.dp).clip(RoundedCornerShape(7.dp))
                                    .background(if (on) Color(0xFF1C2410) else Raise).border(1.dp, if (on) Acc else Line, RoundedCornerShape(7.dp))
                                    .clickable { vm.applyStart(i) }.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("${"%.1f".format(h.seg.s)}s", color = if (on) Acc else Mut, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text(if (h.seg.text.length > 70) h.seg.text.take(70) + "…" else h.seg.text, color = Tx, fontSize = 12.sp, modifier = Modifier.weight(1f).padding(horizontal = 8.dp))
                                h.badge?.let { Text(it, color = Acc, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                    LSlider("Picture focus, left ↔ right", s.cx, 0.0..1.0, 0.01, { "%.2f".format(it) }, onChange = { s.cx = it; vm.preview.requestStill() })
                }

                SectionCard("Frame · Hook · Handle") {
                    Choice("Video ratio inside the reel", Settings.RATIOS, s.rt, { s.rt = it; vm.bump() })
                    Label("Top hook text")
                    OutlinedTextField(s.hk, { s.hk = it; vm.preview.requestStill() }, Modifier.fillMaxWidth(), minLines = 2)
                    Label("Bottom text (channel / handle)")
                    OutlinedTextField(s.hd, { s.hd = it; vm.preview.requestStill() }, Modifier.fillMaxWidth(), singleLine = true)
                    LSlider("Hook size", s.hs, 40.0..110.0, 1.0, onChange = { s.hs = it; vm.preview.requestStill() })
                    LSlider("Video width", s.vw, 60.0..100.0, 1.0, onChange = { s.vw = it; vm.preview.requestStill() })
                    LSlider("Move video up ↔ down", s.cy, -1.0..1.0, 0.02, { "%.2f".format(it) }, onChange = { s.cy = it; vm.preview.requestStill() })
                    Note("Slides the picture inside the frame, so nothing turns black. Drag right to bring the top of the video (forehead) into view. It also works with zoom.")
                    LSlider("Move frame in the reel, up ↔ down", s.vo, -400.0..400.0, 2.0, onChange = { s.vo = it; vm.preview.requestStill() })
                    Note("Moves the whole video frame. This leaves black space above or below it, so use it only to adjust spacing around the hook text.")
                    PlainButton("Reset position", Modifier.fillMaxWidth().padding(top = 8.dp)) { s.vo = 0.0; s.cy = 0.0; s.cx = 0.5; vm.preview.requestStill() }
                    Note("Canvas is always 1080×1920 (Instagram Reel). Black background, hook on top, video in the middle, handle below.")
                }

                SectionCard("2 · Transcript") {
                    OutlinedTextField(
                        s.tr, { s.tr = it; vm.transcriptEdited() }, Modifier.fillMaxWidth().heightIn(min = 110.dp, max = 260.dp),
                        placeholder = { Text("Paste SRT, VTT, [0:05] lines, or plain text (plain text is spread evenly and marked approximate)", fontSize = 12.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Tx)
                    )
                    PlainButton("Load .srt / .vtt / .txt file", Modifier.fillMaxWidth().padding(top = 6.dp)) { pickTr.launch(arrayOf("text/*", "application/x-subrip", "application/octet-stream")) }
                    AccButton("Auto-transcribe from video", vm.busy["asr"] == true, Modifier.fillMaxWidth().padding(top = 8.dp)) { vm.transcribe() }
                    Note(vm.asrn)
                    Note(vm.trn)
                    CheckRow("Blur controversial words in captions", s.bon) { s.bon = it; vm.build() }
                    CheckRow("Bleep (mute + beep) the spoken word in audio", s.bbp) { s.bbp = it; vm.build() }
                    OutlinedTextField(
                        s.bw, { s.bw = it; vm.blurListEdited() }, Modifier.fillMaxWidth().heightIn(min = 90.dp, max = 200.dp),
                        placeholder = { Text("One word or phrase per line (or comma separated)", fontSize = 12.sp) },
                        textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = Tx)
                    )
                    PlainButton("Reset to default list", Modifier.padding(top = 6.dp)) { vm.resetBlurList() }
                    Note(vm.bwn)
                }

                SectionCard("3 · Captions") {
                    Choice("Style", Settings.STYLES, s.sty, { s.applyPreset(it); vm.preview.requestStill() })
                    Row2 {
                        Choice("Words per cue", listOf(2 to "2", 3 to "3", 4 to "4"), s.wn, { s.wn = it; vm.build() }, Modifier.weight(1f))
                        Choice("Font", Settings.FONTS.mapIndexed { i, f -> i to f }, s.fn, { s.fn = it; vm.preview.requestStill() }, Modifier.weight(1f))
                    }
                    LSlider("Size", s.fs, 50.0..150.0, 1.0, onChange = { s.fs = it; vm.preview.requestStill() })
                    LSlider("Caption timing offset (s) · + delays, − earlier", s.co, -0.5..0.5, 0.01, { "%.2f".format(it) }, onChange = { s.co = it; vm.preview.requestStill() })
                    LSlider("Vertical position", s.fy, 30.0..90.0, 1.0, onChange = { s.fy = it; vm.preview.requestStill() })
                    CheckRow("ALL CAPS", s.up) { s.up = it; vm.preview.requestStill() }
                    Label("Highlight colour")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(0xFFFFE14D, 0xFFB8FF3D, 0xFFFF3B3B, 0xFF5EC8FF, 0xFFFF8F5E, 0xFFD68BFF, 0xFFFFFFFF).forEach { cl ->
                            val c = cl.toInt()
                            Box(Modifier.width(30.dp).height(30.dp).clip(RoundedCornerShape(6.dp)).background(Color(c))
                                .border(2.dp, if (s.hc == c) Tx else Line, RoundedCornerShape(6.dp)).clickable { s.hc = c; vm.preview.requestStill() })
                        }
                    }
                }

                SectionCard("4 · B-roll") {
                    NumField("Max B-roll length per clip (seconds)", s.brmax, Modifier.fillMaxWidth()) { s.brmax = it.coerceIn(0.5, 10.0); vm.brMaxChanged() }
                    AccButton("Auto B-roll from captions", vm.busy["brauto"] == true, Modifier.fillMaxWidth().padding(top = 8.dp)) { vm.autoBroll() }
                    Note(vm.brn)
                    Label("Extra trigger words → B-roll clip")
                    var brw by remember { mutableStateOf("") }
                    var brt by remember { mutableStateOf("") }
                    OutlinedTextField(brw, { brw = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("Caption words, comma separated (e.g. needle, jab)", fontSize = 12.sp) })
                    OutlinedTextField(brt, { brt = it }, Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true, placeholder = { Text("B-roll name (e.g. injection or blood_02.mp4)", fontSize = 12.sp) })
                    if (vm.brTargets.isNotEmpty()) Text("Available: " + vm.brTargets.joinToString(", "), color = Mut, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    PlainButton("Add word rule", Modifier.fillMaxWidth().padding(top = 6.dp)) { if (vm.addRule(brw, brt)) { brw = ""; brt = "" } }
                    if (vm.brRules.isEmpty()) Note("No custom words yet. Built-in matching already uses each clip's filename.")
                    vm.brRules.forEachIndexed { i, r ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top = 4.dp)) {
                            Text(r.w.joinToString(", ") + " → " + r.t, color = Mut, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { vm.removeRule(i) }) { Text("×", color = Tx) }
                        }
                    }
                    Label("Your own clips (manual)")
                    PlainButton("Add B-roll files from phone", Modifier.fillMaxWidth()) { pickBr.launch(arrayOf("video/*", "image/*")) }
                    Row2 {
                        PlainButton("Auto-place (manual files)", Modifier.weight(1f)) { vm.autoPlace() }
                        PlainButton("Clear", Modifier.weight(1f)) { vm.clearBroll() }
                    }
                    Note("Auto-place is deterministic (round-robin, no adjacent repeats). Tap a B-roll block on the timeline to remove it.")
                }

                SectionCard("5 · Zoom · Music · Hook SFX") {
                    Choice("Start effect", listOf("none" to "None", "in" to "Zoom in", "out" to "Zoom out"), s.zm, { s.zm = it; vm.bump() })
                    LSlider("Strength %", s.zs, 5.0..50.0, 1.0, onChange = { s.zs = it; vm.preview.requestStill() }, onDone = { vm.report() })
                    LSlider("Duration (s)", s.zd, 0.5..8.0, 0.1, { "%.1f".format(it) }, onChange = { s.zd = it; vm.preview.requestStill() }, onDone = { vm.report() })
                    CheckRow("Keep zooming across the whole clip", s.zw) { s.zw = it; vm.bump() }
                    Note(vm.libn)
                    Choice("Background music", listOf("auto" to "Auto · best track") + vm.bselOptions.map { it to it }, s.bsel, { vm.onBselChange(it) })
                    LSlider("Music volume", s.bv, 0.05..0.6, 0.01, { "%.2f".format(it) }, onChange = { s.bv = it })
                    Row2 {
                        AccButton("Auto BGM", vm.busy["bgmbtn"] == true, Modifier.weight(1f)) { vm.autoBgm() }
                        AccButton("Auto Hook SFX", vm.busy["sfxbtn"] == true, Modifier.weight(1f)) { vm.autoHook() }
                    }
                    CheckRow("Add a random transition sound at the start of B-roll clips (folder: transitionsfx)", s.sfxcut) { s.sfxcut = it; vm.sfxcutChanged() }
                }

                SectionCard("Edit report") {
                    @Suppress("UNUSED_VARIABLE") val r = vm.rev
                    Text(vm.rep, color = Mut, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                }
                Spacer(Modifier.height(90.dp))
            }
        }

        // ---- task toast ----
        vm.task?.let { t ->
            val border = when (t.state) { 1 -> Acc; 2 -> Color(0xFFFF5E5E); else -> Line }
            Column(
                Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(16.dp).fillMaxWidth()
                    .background(Color(0xF21B1D21), RoundedCornerShape(12.dp)).border(1.dp, border, RoundedCornerShape(12.dp)).padding(12.dp)
            ) {
                Text(t.text, color = when (t.state) { 1 -> Acc; 2 -> Color(0xFFFF8F8F); else -> Tx }, fontSize = 13.sp, maxLines = 2)
                if (t.state == 0) {
                    Spacer(Modifier.height(8.dp))
                    if (t.pct != null) LinearProgressIndicator(progress = { t.pct }, modifier = Modifier.fillMaxWidth(), color = Acc)
                    else LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Acc)
                }
            }
        }
    }

    vm.export?.let { ExportDialog(vm, it) }
    if (showSettings) SettingsDialog(vm, onClose = { showSettings = false }, onOpenModel = { showSettings = false; onOpenModel() }, onLogout = onLogout)
    if (vm.needModel) AlertDialog(
        onDismissRequest = { vm.needModel = false },
        title = { Text("Download the transcription model") },
        text = { Text("NVIDIA Parakeet TDT 0.6B v2 (INT8, about 670 MB) is downloaded once from your Cloudflare R2 bucket and stored inside the app. After that, every transcription runs on the phone at full speed with no re-download.") },
        confirmButton = { TextButton(onClick = { vm.needModel = false; onOpenModel() }) { Text("Open model download") } },
        dismissButton = { TextButton(onClick = { vm.needModel = false }) { Text("Later") } }
    )
}
