package com.jare.autoclipper

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import com.jare.autoclipper.editor.BrRule
import com.jare.autoclipper.editor.Core
import com.jare.autoclipper.model.ModelManager
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        prefs = Prefs(getSharedPreferences("clipper", Context.MODE_PRIVATE))
    }

    companion object {
        lateinit var prefs: Prefs
            private set
    }
}

class Prefs(private val sp: SharedPreferences) {
    private fun str(k: String, d: String) = sp.getString(k, d) ?: d
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    var token: String get() = str("clipper_token", ""); set(v) = put("clipper_token", v)
    var modelBase: String get() = str("model_base", ModelManager.DEFAULT_BASE); set(v) = put("model_base", v)
    /** github | web | local */
    var libSource: String get() = str("lib_source", "github"); set(v) = put("lib_source", v)
    var ghRepo: String get() = str("gh_repo", "hackerjinuu/auto-clipper"); set(v) = put("gh_repo", v)
    var ghBranch: String get() = str("gh_branch", "main"); set(v) = put("gh_branch", v)
    var ghToken: String get() = str("gh_token", ""); set(v) = put("gh_token", v)
    var webBase: String get() = str("web_base", ""); set(v) = put("web_base", v)
    var localTree: String get() = str("local_tree", ""); set(v) = put("local_tree", v)
    var blurWords: String get() = str("blurWords", "").ifBlank { Core.BL_DEFAULT.joinToString("\n") }; set(v) = put("blurWords", v)
    var modelPrompted: Boolean get() = sp.getBoolean("model_prompted", false); set(v) = sp.edit().putBoolean("model_prompted", v).apply()

    var brRules: List<BrRule>
        get() = try {
            val a = JSONArray(str("brRules", "[]"))
            (0 until a.length()).mapNotNull { i ->
                val o = a.getJSONObject(i); val w = o.optJSONArray("w") ?: return@mapNotNull null
                val t = o.optString("t"); if (t.isBlank()) null else BrRule((0 until w.length()).map { w.getString(it) }, t)
            }
        } catch (e: Exception) { emptyList() }
        set(v) = put("brRules", JSONArray(v.map { JSONObject().put("w", JSONArray(it.w)).put("t", it.t) }).toString())
}

/** Same login endpoint as the website. */
object AuthApi {
    private val http = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    private const val URL = "https://app-backend-delta-livid.vercel.app/v1/auth/login"

    fun login(email: String, password: String): String {
        val body = JSONObject().put("email", email).put("password", password).toString().toRequestBody("application/json".toMediaType())
        val req = Request.Builder().url(URL).post(body).header("x-app-version", "2").build()
        http.newCall(req).execute().use { r ->
            val txt = r.body?.string() ?: ""
            val j = try { JSONObject(txt) } catch (e: Exception) { JSONObject() }
            if (!r.isSuccessful) throw IOException(j.optString("error").ifBlank { "Invalid credentials" })
            return j.optString("token").ifBlank { throw IOException("No token in reply") }
        }
    }
}
