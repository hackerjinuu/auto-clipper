package com.jare.autoclipper.editor

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import com.jare.autoclipper.media.VFrame
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** What the renderer needs to know about the edit. Implemented by the EditorViewModel. */
interface Project {
    val s: Settings
    val hasVideo: Boolean
    val cues: List<Cue>
    val broll: List<BrollItem>
    fun clipLen(): Double
    fun otime(ts: Double): Double
}

/**
 * Draws one 1080×1920 reel frame (the web editor's draw()): black background, hook text on top,
 * framed video (or B-roll) in the middle, handle below, animated captions with blurred words.
 * Use one instance per thread.
 */
class Renderer(private val p: Project) {
    companion object {
        const val W = 1080f
        const val H = 1920f
        private val hookTf: Typeface = Typeface.create(Typeface.SANS_SERIF, 600, false)
        private val handleTf: Typeface = Typeface.create(Typeface.SANS_SERIF, 500, false)
        private val condensed = Typeface.create("sans-serif-condensed", Typeface.NORMAL)
        fun captionFont(fn: Int, minimal: Boolean): Typeface {
            val w = if (minimal) 400 else 900
            return when (fn) {
                1 -> Typeface.create(Typeface.SANS_SERIF, w, false)
                2 -> Typeface.create(Typeface.SERIF, w, false)
                else -> Typeface.create(condensed, w, false)
            }
        }
    }

    class Frame(val full: Boolean, val x: Float, val y: Float, val w: Float, val h: Float,
                val lines: List<String> = emptyList(), val hs: Float = 0f, val hl: Float = 1.18f, val top: Float = 0f, val asz: Float = 0f, val ay: Float = 0f)

    private val text = Paint(Paint.ANTI_ALIAS_FLAG or Paint.SUBPIXEL_TEXT_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; color = Color.BLACK }
    private val box = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bmpPaint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val blurCache = object : LinkedHashMap<String, Bitmap>(32, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, Bitmap>?) = size > 40
    }

    private fun wrapLines(txt: String, maxW: Float): List<String> {
        val words = txt.split(Regex("\\s+")).filter { it.isNotEmpty() }
        val lines = ArrayList<String>(); var cur = ""
        for (w in words) { val t = if (cur.isNotEmpty()) "$cur $w" else w; if (text.measureText(t) > maxW && cur.isNotEmpty()) { lines.add(cur); cur = w } else cur = t }
        if (cur.isNotEmpty()) lines.add(cur)
        return lines
    }

    fun layout(): Frame {
        val s = p.s
        if (s.rt == "full") return Frame(true, 0f, 0f, W, H)
        val r = (Settings.FR[s.rt] ?: 1.0).toFloat()
        var bw = W * (s.vw / 100).toFloat(); var bh = bw / r
        val maxH = 1250f
        if (bh > maxH) { bh = maxH; bw = bh * r }
        val hs = s.hs.toFloat(); val hl = 1.18f; val asz = (hs * 0.75f).roundToInt().toFloat()
        text.typeface = hookTf; text.textSize = hs
        val lines = wrapLines(s.hk, W - 40)
        val hh = lines.size * hs * hl; val gap = hs * 0.28f; val ah = if (s.hd.isNotEmpty()) asz * 1.25f else 0f
        val total = hh + (if (hh > 0) gap else 0f) + bh + (if (ah > 0) gap else 0f) + ah
        val top = (H - total) / 2; val vy = top + hh + (if (hh > 0) gap else 0f)
        return Frame(false, (W - bw) / 2, vy + s.vo.toFloat(), bw, bh, lines, hs, hl, top, asz, vy + bh + gap)
    }

    private fun mid(pt: Paint): Float { val fm = pt.fontMetrics; return -(fm.ascent + fm.descent) / 2 }

    private fun frameText(c: Canvas, F: Frame) {
        text.clearShadowLayer(); text.color = Color.WHITE; text.textAlign = Paint.Align.CENTER
        text.typeface = hookTf; text.textSize = F.hs
        val m = mid(text)
        F.lines.forEachIndexed { i, l -> c.drawText(l, W / 2, F.top + (i + 0.5f) * F.hs * F.hl + m, text) }
        if (p.s.hd.isNotEmpty()) {
            text.typeface = handleTf; text.textSize = F.asz
            c.drawText(p.s.hd, W / 2, F.ay + F.asz * 0.65f + mid(text), text)
        }
        text.textAlign = Paint.Align.LEFT
    }

    /** draws a frame (crop + rotation) into the box x,y,w,h (display orientation) */
    private fun drawFrame(c: Canvas, vf: VFrame, x: Float, y: Float, w: Float, h: Float) {
        if (vf.bmp.isRecycled) return
        c.save()
        c.translate(x + w / 2, y + h / 2)
        c.scale(w / vf.dispW, h / vf.dispH)
        c.rotate(vf.rotation.toFloat())
        val cw = vf.crop.width() / 2f; val ch = vf.crop.height() / 2f
        c.drawBitmap(vf.bmp, vf.crop, RectF(-cw, -ch, cw, ch), bmpPaint)
        c.restore()
    }

    /**
     * @param S scale (1 = 1080p, 2 = 4K)
     * @param ct source time of the main video
     * @param main main video frame at ct (null = not loaded)
     * @param br returns the B-roll frame for (item, seconds into the item)
     */
    fun draw(c: Canvas, S: Float, ct: Double, main: VFrame?, br: ((BrollItem, Double) -> VFrame?)?) {
        val s = p.s
        c.save(); c.scale(S, S)
        c.drawColor(Color.BLACK)
        val F = layout()
        if (!F.full) frameText(c, F)
        if (!p.hasVideo && !F.full) { box.color = 0xFF161616.toInt(); c.drawRect(F.x, F.y, F.x + F.w, F.y + F.h, box) }
        if (p.hasVideo) {
            val rel = p.otime(ct)
            val b = p.broll.firstOrNull { it.dur > 0 && rel >= it.start && rel < it.start + it.dur }
            c.save(); c.clipRect(F.x, F.y, F.x + F.w, F.y + F.h)
            val bf = if (b != null) br?.invoke(b, rel - b.start) else null
            if (bf != null) {
                val k = max(F.w / bf.dispW, F.h / bf.dispH)
                drawFrame(c, bf, F.x + (F.w - bf.dispW * k) / 2, F.y + (F.h - bf.dispH * k) / 2, bf.dispW * k, bf.dispH * k)
            } else if (main != null) {
                val dw = main.dispW.toFloat(); val dh = main.dispH.toFloat()
                val k = max(F.w / dw, F.h / dh)
                var x = F.x + (F.w - dw * k) * s.cx.toFloat()
                var y = F.y + (F.h - dh * k) * (0.5f - s.cy.toFloat() / 2)
                var w = dw * k; var h = dh * k
                val z = Core.zoomK(s.zm, s.zs, s.zd, s.zw, p.clipLen(), rel).toFloat()
                if (z != 1f) { val mx = F.x + F.w / 2; val my = F.y + F.h / 2; x = mx + (x - mx) * z; y = my + (y - my) * z; w *= z; h *= z }
                drawFrame(c, main, x, y, w, h)
            }
            c.restore()
            drawCaptions(c, F, ct)
        }
        c.restore()
    }

    /** Animated caption for source time ct0 (web: caption block of draw()). */
    fun drawCaptions(c: Canvas, F: Frame, ct0: Double) {
        val s = p.s
        val ct = ct0 - s.co
        val cue = p.cues.firstOrNull { ct >= it.s && ct < it.e } ?: return
        val sty = s.sty
        val age = min(1.0, (ct - cue.s) / 0.1).toFloat()
        val sc = if (sty == "minimal") 1f else 1.15f - 0.15f * age
        val size = (s.fs * (if (F.full) 1.0 else 0.6)).toFloat()
        val y = F.y + F.h * (s.fy / 100).toFloat()
        val words = cue.words.map { if (s.up) it.uppercase() else it }
        val alpha = ((0.4f + 0.6f * age) * 255).roundToInt().coerceIn(0, 255)
        c.save(); c.translate(W / 2, y); c.scale(sc, sc)
        val tf = captionFont(s.fn, sty == "minimal")
        text.typeface = tf; text.textSize = size; text.textAlign = Paint.Align.LEFT
        stroke.typeface = tf; stroke.textSize = size; stroke.strokeWidth = size / 9
        val gap = size * 0.28f
        val ws = words.map { text.measureText(it) }
        val total = ws.sum() + gap * (words.size - 1)
        var kw = 0
        words.forEachIndexed { i, w -> if (w.length > words[kw].length) kw = i }
        if (sty == "karaoke") { kw = 0; cue.wt.forEachIndexed { i, x -> if (ct >= x.s) kw = i } }
        if (sty == "box") {
            val pw = total + size * 0.8f; val ph = size * 1.5f
            box.color = Color.argb((0.72f * alpha).roundToInt(), 0, 0, 0)
            c.drawRoundRect(-pw / 2, -ph / 2, pw / 2, ph / 2, size * 0.3f, size * 0.3f, box)
        }
        val base = mid(text)
        val strokeOn = sty == "kinetic" || sty == "karaoke" || sty == "redkw"
        var x = -total / 2
        words.forEachIndexed { i, w ->
            val colr = if (i == kw && sty != "minimal") s.hc else Color.WHITE
            if (cue.wt.getOrNull(i)?.bl == true) {
                drawBlur(c, w, x, base, size, colr, strokeOn, tf, alpha)
                x += ws[i] + gap; return@forEachIndexed
            }
            if (strokeOn) {
                stroke.setShadowLayer(14f * 0.85f, 0f, 4f, Color.argb((0.8f * alpha).roundToInt(), 0, 0, 0))
                stroke.alpha = alpha
                c.drawText(w, x, base, stroke)
                text.setShadowLayer(14f * 0.85f, 0f, 4f, Color.argb((0.8f * alpha).roundToInt(), 0, 0, 0))
            } else if (sty == "minimal") {
                text.setShadowLayer(6f * 0.85f, 0f, 2f, Color.argb((0.6f * alpha).roundToInt(), 0, 0, 0))
            } else text.clearShadowLayer()
            text.color = colr; text.alpha = alpha
            c.drawText(w, x, base, text)
            x += ws[i] + gap
        }
        text.clearShadowLayer(); stroke.clearShadowLayer()
        c.restore()
    }

    /** A blurred word: drawn small, softened, then scaled back up (works on hardware canvases). */
    private fun drawBlur(c: Canvas, w: String, x: Float, base: Float, size: Float, colr: Int, strokeOn: Boolean, tf: Typeface, alpha: Int) {
        val key = "$w|$size|$colr|$strokeOn|${tf.hashCode()}"
        val pad = size * 0.5f
        val f = max(2f, size * 0.2f / 2f)
        val fm = text.fontMetrics
        val tw = text.measureText(w)
        val bmp = blurCache.getOrPut(key) {
            val bw = ceil((tw + 2 * pad) / f).toInt().coerceAtLeast(1)
            val bh = ceil((fm.descent - fm.ascent + 2 * pad) / f).toInt().coerceAtLeast(1)
            val b = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
            val cv = Canvas(b); cv.scale(1 / f, 1 / f)
            val tp = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = tf; textSize = size }
            val bl = pad - fm.ascent
            if (strokeOn) { tp.style = Paint.Style.STROKE; tp.strokeWidth = size / 9; tp.strokeJoin = Paint.Join.ROUND; tp.color = Color.BLACK; cv.drawText(w, pad, bl, tp) }
            tp.style = Paint.Style.FILL; tp.color = colr; cv.drawText(w, pad, bl, tp)
            boxBlur(b); boxBlur(b)
            b
        }
        bmpPaint.alpha = alpha
        val top = base + fm.ascent - pad
        c.drawBitmap(bmp, null, RectF(x - pad, top, x - pad + bmp.width * f, top + bmp.height * f), bmpPaint)
        bmpPaint.alpha = 255
    }

    private fun boxBlur(b: Bitmap) {
        val w = b.width; val h = b.height
        val src = IntArray(w * h); b.getPixels(src, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        fun pass(a: IntArray, o: IntArray, horiz: Boolean) {
            for (yy in 0 until h) for (xx in 0 until w) {
                var A = 0; var R = 0; var G = 0; var B = 0; var n = 0
                for (d in -1..1) {
                    val sx = if (horiz) xx + d else xx; val sy = if (horiz) yy else yy + d
                    if (sx < 0 || sy < 0 || sx >= w || sy >= h) continue
                    val px = a[sy * w + sx]
                    A += px ushr 24; R += (px shr 16) and 0xff; G += (px shr 8) and 0xff; B += px and 0xff; n++
                }
                o[yy * w + xx] = ((A / n) shl 24) or ((R / n) shl 16) or ((G / n) shl 8) or (B / n)
            }
        }
        pass(src, tmp, true); pass(tmp, src, false)
        b.setPixels(src, 0, w, 0, 0, w, h)
    }
}
