package com.jare.autoclipper.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.jare.autoclipper.App
import com.jare.autoclipper.editor.EditorViewModel
import com.jare.autoclipper.editor.ExportUi
import com.jare.autoclipper.editor.Library

@Composable
private fun OptBox(title: String, sub: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.background(if (on) Acc.copy(alpha = 0.1f) else Raise, RoundedCornerShape(8.dp))
            .border(1.dp, if (on) Acc else Line, RoundedCornerShape(8.dp)).clickable { onClick() }.padding(10.dp)
    ) {
        Text(title, fontWeight = FontWeight.Bold, color = Tx, fontSize = 13.sp)
        Text(sub, color = Mut, fontSize = 12.sp)
    }
}

@Composable
fun ExportDialog(vm: EditorViewModel, e: ExportUi) {
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = { vm.closeExport() },
        properties = DialogProperties(dismissOnClickOutside = e.stage != 1, dismissOnBackPress = e.stage != 1),
        title = { Text(if (e.stage == 0) "Export video" else e.title) },
        text = {
            Column {
                if (e.stage == 0) {
                    Text("Rendered frame by frame, so the file is smooth with audio in sync.", color = Mut, fontSize = 12.sp)
                    Label("Resolution")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OptBox("Full HD · 1080p", "1080 × 1920", e.res == 1080, Modifier.weight(1f)) { vm.setExportOpt(res = 1080) }
                        OptBox("Ultra HD · 4K", "2160 × 3840", e.res == 2160, Modifier.weight(1f)) { vm.setExportOpt(res = 2160) }
                    }
                    Label("Frame rate")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OptBox("30 fps", "Fast, smooth", e.fps == 30, Modifier.weight(1f)) { vm.setExportOpt(fps = 30) }
                        OptBox("60 fps", "Extra smooth", e.fps == 60, Modifier.weight(1f)) { vm.setExportOpt(fps = 60) }
                    }
                    Note(vm.exportSummary(e.res, e.fps))
                } else {
                    LinearProgressIndicator(progress = { e.pct }, modifier = Modifier.fillMaxWidth().padding(vertical = 10.dp), color = if (e.stage == 2) Color(0xFF5EF08A) else Acc)
                    Text(e.note, color = Mut, fontSize = 12.sp)
                }
            }
        },
        confirmButton = {
            when (e.stage) {
                0 -> TextButton(onClick = { vm.runExport() }) { Text("⬇ Export & save", color = Acc, fontWeight = FontWeight.Bold) }
                1 -> TextButton(onClick = { vm.cancelExport() }) { Text("Cancel") }
                2 -> Row {
                    TextButton(onClick = {
                        e.outUri?.let { u -> runCatching { ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } }
                    }) { Text("▶ Play") }
                    TextButton(onClick = {
                        e.outUri?.let { u ->
                            val i = Intent(Intent.ACTION_SEND).setType("video/mp4").putExtra(Intent.EXTRA_STREAM, u).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            runCatching { ctx.startActivity(Intent.createChooser(i, "Share video")) }
                        }
                    }) { Text("Share", color = Acc) }
                }
                else -> TextButton(onClick = { vm.export = null }) { Text("Close") }
            }
        },
        dismissButton = {
            when (e.stage) {
                0 -> Row {
                    TextButton(onClick = { vm.closeExport(); vm.togglePlay() }) { Text("▶ Preview") }
                    TextButton(onClick = { vm.closeExport() }) { Text("Close") }
                }
                2 -> TextButton(onClick = { vm.export = null }) { Text("Close") }
                else -> {}
            }
        }
    )
}

@Composable
fun SettingsDialog(vm: EditorViewModel, onClose: () -> Unit, onOpenModel: () -> Unit, onLogout: () -> Unit) {
    val p = App.prefs
    val ctx = LocalContext.current
    var src by remember { mutableStateOf(p.libSource) }
    var repo by remember { mutableStateOf(p.ghRepo) }
    var branch by remember { mutableStateOf(p.ghBranch) }
    var token by remember { mutableStateOf(p.ghToken) }
    var web by remember { mutableStateOf(p.webBase) }
    var tree by remember { mutableStateOf(p.localTree) }
    val pickTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u: Uri? ->
        if (u != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            tree = u.toString()
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Settings") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Library source (bgm, best hook, transitionsfx, broll)", fontWeight = FontWeight.SemiBold, color = Tx, fontSize = 13.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp)) {
                    OptBox("GitHub", "repo folders", src == "github", Modifier.weight(1f)) { src = "github" }
                    OptBox("Website", "library.json", src == "web", Modifier.weight(1f)) { src = "web" }
                    OptBox("Phone", "local folder", src == "local", Modifier.weight(1f)) { src = "local" }
                }
                when (src) {
                    "github" -> {
                        OutlinedTextField(repo, { repo = it }, Modifier.fillMaxWidth().padding(top = 6.dp), label = { Text("owner/repo") }, singleLine = true)
                        OutlinedTextField(branch, { branch = it }, Modifier.fillMaxWidth(), label = { Text("Branch") }, singleLine = true)
                        OutlinedTextField(token, { token = it }, Modifier.fillMaxWidth(), label = { Text("Token (only for a private repo)") }, singleLine = true)
                    }
                    "web" -> OutlinedTextField(web, { web = it }, Modifier.fillMaxWidth().padding(top = 6.dp), label = { Text("Website address, e.g. https://your-site.vercel.app") }, singleLine = true)
                    else -> {
                        Note(if (tree.isBlank()) "No folder picked yet. Pick the folder that contains bgm, best hook, transitionsfx and broll." else "Folder: " + Uri.parse(tree).lastPathSegment)
                        PlainButton("Pick project folder", Modifier.fillMaxWidth().padding(top = 6.dp)) { pickTree.launch(null) }
                    }
                }
                Note("Files are downloaded once and kept in the app, then reused.")
                Text("Transcription model", fontWeight = FontWeight.SemiBold, color = Tx, fontSize = 13.sp, modifier = Modifier.padding(top = 14.dp))
                PlainButton("Manage Parakeet model", Modifier.fillMaxWidth().padding(top = 6.dp)) { onOpenModel() }
                PlainButton("Log out", Modifier.fillMaxWidth().padding(top = 14.dp)) { onLogout() }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                p.libSource = src; p.ghRepo = repo.trim(); p.ghBranch = branch.trim().ifEmpty { "main" }; p.ghToken = token.trim(); p.webBase = web.trim(); p.localTree = tree
                Library.invalidate()
                onClose()
            }) { Text("Save", color = Acc) }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}
