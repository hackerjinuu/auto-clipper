package com.jare.autoclipper.editor

import android.graphics.Rect
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.HandlerThread
import android.util.Log
import android.view.SurfaceHolder
import com.jare.autoclipper.media.FrameSource
import com.jare.autoclipper.media.MediaUtil
import com.jare.autoclipper.media.VFrame
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToLong

/**
 * The 9:16 preview canvas. Paused: draws a still at the playhead. Playing: plays the exact
 * export mix through AudioTrack and draws decoded frames in sync with the audio clock,
 * using the same Renderer as the export, so what you see is what you export.
 */
class PreviewEngine(private val vm: EditorViewModel) : SurfaceHolder.Callback {
    @Volatile private var holder: SurfaceHolder? = null
    private val ht = HandlerThread("preview-still").apply { start() }
    private val h = Handler(ht.looper)
    private val stillRenderer = Renderer(vm)
    private var retr: MediaMetadataRetriever? = null
    private var retrUri: Uri? = null
    private var stillKey = Long.MIN_VALUE
    private var stillFrame: VFrame? = null
    private var stillBroll: BrollFrames? = null
    @Volatile var playing = false; private set
    private var playThread: Thread? = null

    override fun surfaceCreated(holder: SurfaceHolder) { this.holder = holder; requestStill() }
    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) { this.holder = holder; requestStill() }
    override fun surfaceDestroyed(holder: SurfaceHolder) { stop(); playThread?.join(1500); this.holder = null }

    private val stillRun = Runnable { drawStill() }
    fun requestStill() { h.removeCallbacks(stillRun); h.postDelayed(stillRun, 16) }

    /** forget the cached still (new source) */
    fun resetSource() = h.post {
        runCatching { retr?.release() }; retr = null; retrUri = null; stillKey = Long.MIN_VALUE; stillFrame = null
        stillBroll?.close(); stillBroll = null
    }

    private fun stillAt(ts: Double): VFrame? {
        val uri = vm.srcUri ?: return null
        val key = (ts * 100).roundToLong()
        if (key == stillKey && retrUri == uri) return stillFrame
        if (retrUri != uri) {
            runCatching { retr?.release() }
            retr = MediaMetadataRetriever().also { MediaUtil.setSource(it, vm.ctx, uri) }; retrUri = uri
        }
        val b = try { retr!!.getScaledFrameAtTime((ts * 1e6).toLong(), MediaMetadataRetriever.OPTION_CLOSEST, 1280, 1280) } catch (e: Exception) { null }
        if (b != null) { stillFrame = VFrame(b, Rect(0, 0, b.width, b.height), 0); stillKey = key }
        return stillFrame
    }

    private fun drawStill() {
        if (playing) return
        val hd = holder ?: return
        try {
            val ts = if (vm.hasVideo) vm.stime(vm.phRel) else 0.0
            val vf = if (vm.hasVideo) stillAt(ts) else null
            val bf = stillBroll ?: BrollFrames(vm.ctx).also { stillBroll = it }
            val c = hd.lockHardwareCanvas() ?: return
            try { stillRenderer.draw(c, 1f, ts, vf) { b, local -> runCatching { bf.still(b, local) }.getOrNull() } }
            finally { hd.unlockCanvasAndPost(c) }
        } catch (e: Exception) { Log.w("Preview", "still", e) }
    }

    fun play() {
        if (playing || !vm.hasVideo) return
        playing = true
        vm.onPlayState(true)
        playThread = Thread({ runPlayback() }, "preview-play").also { it.start() }
    }

    fun stop() { playing = false }

    private fun runPlayback() {
        var track: AudioTrack? = null
        var fs: FrameSource? = null
        val bf = BrollFrames(vm.ctx)
        val renderer = Renderer(vm)
        try {
            vm.post { vm.stat = "Preparing preview (mixing audio)…" }
            val L = vm.clipLen()
            val mix = vm.mixBlocking { !playing }
            if (!playing) return
            val minBuf = AudioTrack.getMinBufferSize(AudioMixer.SR, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
            track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_FLOAT).setSampleRate(AudioMixer.SR).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setBufferSizeInBytes(max(minBuf, AudioMixer.SR * 2 * 4 / 5))
                .build()
            fs = FrameSource.open(vm.ctx, vm.srcUri!!)
            val R0 = vm.ranges()
            fs.frameAt(R0.first().a)
            val totalFrames = mix.size / 2
            val tr = track
            val writer = Thread {
                var pos = 0
                while (playing && pos < mix.size) {
                    val n = min(4800 * 2, mix.size - pos)
                    val w = tr.write(mix, pos, n, AudioTrack.WRITE_BLOCKING)
                    if (w <= 0) break
                    pos += w
                }
            }
            tr.play(); writer.start()
            vm.post { vm.stat = "Playing preview" }
            var lastUi = 0L
            while (playing) {
                val head = tr.playbackHeadPosition
                val rel = head.toDouble() / AudioMixer.SR
                if (rel >= L - 0.01 || head >= totalFrames - 1) break
                val ts = vm.stime(rel)
                val vf = fs.frameAt(ts)
                val hd = holder ?: break
                val c = hd.lockHardwareCanvas() ?: break
                try { renderer.draw(c, 1f, ts, vf) { b, local -> runCatching { bf.frame(b, local) }.getOrNull() } }
                finally { hd.unlockCanvasAndPost(c) }
                val now = System.currentTimeMillis()
                if (now - lastUi > 80) { lastUi = now; vm.post { vm.phRel = rel } }
            }
            writer.interrupt()
        } catch (e: Exception) {
            Log.e("Preview", "playback", e)
            vm.post { vm.stat = "Preview failed: " + (e.message ?: e.toString()) }
        } finally {
            playing = false
            runCatching { track?.pause(); track?.flush(); track?.stop() }; runCatching { track?.release() }
            runCatching { fs?.close() }; bf.close()
            vm.post { vm.onPlayState(false); if (vm.stat.startsWith("Playing") || vm.stat.startsWith("Preparing")) vm.stat = "Stopped." }
            requestStill()
        }
    }

    fun release() {
        stop(); playThread?.join(1500)
        h.post { runCatching { retr?.release() }; stillBroll?.close() }
        ht.quitSafely()
    }
}
