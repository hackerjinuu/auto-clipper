package com.jare.autoclipper.media

import android.graphics.Canvas
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import android.view.Surface
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.roundToInt

/**
 * Frame-accurate offline export to MP4 (H.264 + AAC), the native version of the web
 * editor's WebCodecs export. Every frame is drawn with an Android Canvas straight onto
 * the hardware encoder's input surface, then muxed with the pre-mixed audio.
 */
class Exporter(private val out: File, private val w: Int, private val h: Int, private val fps: Int, private val bitrate: Int) {

    class Cancelled : Exception("Cancelled.")

    private class Sample(val data: ByteArray, val pts: Long, val flags: Int)

    companion object {
        fun canEncode(w: Int, h: Int, fps: Int): Boolean =
            MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(videoFormat(w, h, fps, 8_000_000)) != null

        fun videoFormat(w: Int, h: Int, fps: Int, br: Int): MediaFormat = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, br)
            setInteger(MediaFormat.KEY_FRAME_RATE, fps)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        }
    }

    /** audio = interleaved stereo float at 48 kHz. drawFrame(canvas, i) renders frame i. */
    fun run(frames: Int, audio: FloatArray, cancel: () -> Boolean, progress: (Int) -> Unit, drawFrame: (Canvas, Int) -> Unit) {
        // ---- 1. audio -> AAC (kept in memory, small) ----
        val aSamples = ArrayList<Sample>()
        var aFormat: MediaFormat? = null
        run {
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, 48000, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 192_000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 1 shl 16)
            }
            val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            try {
                enc.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); enc.start()
                val total = audio.size / 2; var pos = 0; var inEos = false
                val info = MediaCodec.BufferInfo()
                while (true) {
                    if (cancel()) throw Cancelled()
                    if (!inEos) {
                        val ii = enc.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val b = enc.getInputBuffer(ii)!!.order(ByteOrder.nativeOrder()); b.clear()
                            val n = minOf(b.remaining() / 4, total - pos)
                            if (n <= 0) { enc.queueInputBuffer(ii, 0, 0, pos * 1_000_000L / 48000, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inEos = true }
                            else {
                                for (k in 0 until n * 2) {
                                    val v = audio[pos * 2 + k]
                                    b.putShort((if (v > 1f) 1f else if (v < -1f) -1f else v).times(32767f).roundToInt().toShort())
                                }
                                enc.queueInputBuffer(ii, 0, n * 4, pos * 1_000_000L / 48000, 0); pos += n
                            }
                        }
                    }
                    val oi = enc.dequeueOutputBuffer(info, 10_000)
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) aFormat = enc.outputFormat
                    else if (oi >= 0) {
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0) {
                            val b = enc.getOutputBuffer(oi)!!; b.position(info.offset); b.limit(info.offset + info.size)
                            val d = ByteArray(info.size); b.get(d)
                            aSamples.add(Sample(d, info.presentationTimeUs, info.flags))
                        }
                        enc.releaseOutputBuffer(oi, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            } finally { runCatching { enc.stop() }; enc.release() }
        }
        val audioFmt = aFormat ?: throw IOException("Audio encoder gave no format")

        // ---- 2. video encoder fed by Canvas ----
        val vf = videoFormat(w, h, fps, bitrate)
        try { vf.setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0) } catch (_: Exception) {}
        val name = MediaCodecList(MediaCodecList.REGULAR_CODECS).findEncoderForFormat(videoFormat(w, h, fps, bitrate))
            ?: throw IOException("This phone cannot encode ${w}×$h at $fps fps. Try Full HD or 30 fps.")
        val venc = MediaCodec.createByCodecName(name)
        venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        val surface: Surface = venc.createInputSurface()
        venc.start()
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        val drainErr = java.util.concurrent.atomic.AtomicReference<Throwable?>(null)
        var written = 0
        val drain = Thread {
            try {
                val info = MediaCodec.BufferInfo()
                var vTrack = -1; var started = false
                while (true) {
                    val oi = venc.dequeueOutputBuffer(info, 10_000)
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        vTrack = muxer.addTrack(venc.outputFormat)
                        val aTrack = muxer.addTrack(audioFmt)
                        muxer.start(); started = true
                        val ai = MediaCodec.BufferInfo()
                        for (s in aSamples) {
                            ai.set(0, s.data.size, s.pts, s.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM.inv())
                            muxer.writeSampleData(aTrack, ByteBuffer.wrap(s.data), ai)
                        }
                    } else if (oi >= 0) {
                        val eos = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0 && info.size > 0 && started) {
                            val b = venc.getOutputBuffer(oi)!!; b.position(info.offset); b.limit(info.offset + info.size)
                            // frames come out in order (no B-frames), so give each its exact slot on the timeline
                            info.presentationTimeUs = written * 1_000_000L / fps
                            muxer.writeSampleData(vTrack, b, info); written++
                        }
                        venc.releaseOutputBuffer(oi, false)
                        if (eos) break
                    }
                }
            } catch (t: Throwable) { drainErr.set(t); Log.e("Exporter", "drain", t) }
        }
        drain.start()
        var ok = false
        try {
            val minGapNs = 1_000_000_000L / fps / 2 // never post faster than 2x real time (keeps encoder rate control sane)
            var lastPost = 0L
            for (i in 0 until frames) {
                if (cancel()) throw Cancelled()
                drainErr.get()?.let { throw IOException("Encoder error: " + it.message) }
                val c = surface.lockHardwareCanvas()
                try { drawFrame(c, i) } finally { surface.unlockCanvasAndPost(c) }
                val now = System.nanoTime(); val wait = minGapNs - (now - lastPost)
                if (wait > 0) Thread.sleep(wait / 1_000_000, (wait % 1_000_000).toInt())
                lastPost = System.nanoTime()
                progress(i)
            }
            venc.signalEndOfInputStream()
            drain.join(20_000)
            drainErr.get()?.let { throw IOException("Encoder error: " + it.message) }
            ok = true
        } finally {
            if (!ok) { runCatching { venc.signalEndOfInputStream() }; drain.join(3000) }
            runCatching { venc.stop() }; runCatching { venc.release() }; runCatching { surface.release() }
            runCatching { muxer.stop() }; runCatching { muxer.release() }
            if (!ok) out.delete()
        }
        Log.i("Exporter", "frames in=$frames out=$written")
    }
}
