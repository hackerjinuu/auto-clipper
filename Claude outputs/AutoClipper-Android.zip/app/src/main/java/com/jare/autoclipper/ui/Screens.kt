package com.jare.autoclipper.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.work.WorkInfo
import com.jare.autoclipper.App
import com.jare.autoclipper.AuthApi
import com.jare.autoclipper.asr.ParakeetEngine
import com.jare.autoclipper.model.ModelManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun LoginScreen(onDone: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Column(
            Modifier.widthIn(max = 360.dp).padding(20.dp).background(Panel, RoundedCornerShape(14.dp))
                .border(1.dp, Line, RoundedCornerShape(14.dp)).padding(horizontal = 24.dp, vertical = 30.dp)
        ) {
            Text("Welcome Back", fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Tx)
            Text("Sign in to access Auto Clipper", color = Mut, fontSize = 13.sp, modifier = Modifier.padding(bottom = 16.dp))
            if (err.isNotEmpty()) Text(err, color = Color(0xFFFF8F8F), fontSize = 12.sp,
                modifier = Modifier.fillMaxWidth().background(Color(0x1AFF5E5E), RoundedCornerShape(6.dp)).padding(8.dp))
            OutlinedTextField(email, { email = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("Email Address") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email))
            OutlinedTextField(pass, { pass = it }, Modifier.fillMaxWidth().padding(top = 8.dp), label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
            Spacer(Modifier.height(18.dp))
            AccButton(if (busy) "Verifying..." else "Access Studio", busy, Modifier.fillMaxWidth()) {
                busy = true; err = ""
                scope.launch {
                    try {
                        val t = withContext(Dispatchers.IO) { AuthApi.login(email.trim(), pass) }
                        App.prefs.token = t
                        onDone()
                    } catch (e: Exception) { err = e.message ?: "Invalid credentials" } finally { busy = false }
                }
            }
        }
    }
}

@Composable
fun ModelScreen(onContinue: () -> Unit) {
    val ctx = LocalContext.current
    val mm = remember { ModelManager(ctx) }
    val flow = remember { mm.progress() }
    val infos by flow.collectAsState(initial = emptyList())
    val wi = infos.firstOrNull()
    var ready by remember { mutableStateOf(mm.isReady()) }
    var base by remember { mutableStateOf(App.prefs.modelBase) }
    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { mm.start() }
    LaunchedEffect(wi?.state) { if (wi?.state == WorkInfo.State.SUCCEEDED) ready = mm.isReady() }
    val running = wi != null && (wi.state == WorkInfo.State.RUNNING || wi.state == WorkInfo.State.ENQUEUED || wi.state == WorkInfo.State.BLOCKED)
    val done = wi?.progress?.getLong("done", 0L) ?: 0L
    val total = wi?.progress?.getLong("total", 0L) ?: 0L
    val file = wi?.progress?.getString("file") ?: ""
    val error = if (wi?.state == WorkInfo.State.FAILED) (wi?.outputData?.getString("error") ?: "unknown error") else null

    Box(Modifier.fillMaxSize().background(Bg), contentAlignment = Alignment.Center) {
        Column(
            Modifier.widthIn(max = 440.dp).padding(16.dp).background(Panel, RoundedCornerShape(14.dp)).border(1.dp, Line, RoundedCornerShape(14.dp))
                .padding(20.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("Transcription model", fontWeight = FontWeight.Bold, fontSize = 19.sp, color = Tx)
            Text("NVIDIA Parakeet TDT 0.6B v2 · INT8 ONNX (encoder + decoder/joint + vocab, about 670 MB).", color = Mut, fontSize = 13.sp)
            Text("It is downloaded ONE time from your Cloudflare R2 bucket and stored inside the app. After that it always loads from the phone, so it never downloads again and runs natively at full speed (ONNX Runtime, multi-threaded).", color = Mut, fontSize = 13.sp)
            when {
                ready -> {
                    Text("✓ Model is on this phone (${mm.sizeOnDisk() / 1_048_576} MB).", color = Acc, fontWeight = FontWeight.SemiBold)
                    AccButton("Continue to editor", modifier = Modifier.fillMaxWidth()) { onContinue() }
                    PlainButton("Delete model from phone", Modifier.fillMaxWidth()) { mm.delete(); ready = false }
                }
                running -> {
                    Text(if (wi?.state == WorkInfo.State.ENQUEUED) "Waiting for network…" else "Downloading $file…", color = Tx)
                    if (total > 0) {
                        LinearProgressIndicator(progress = { (done.toFloat() / total).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth(), color = Acc)
                        Text("${done / 1_048_576} / ${total / 1_048_576} MB · keeps going in the background, and resumes if the connection drops.", color = Mut, fontSize = 12.sp)
                    } else LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Acc)
                    PlainButton("Cancel", Modifier.fillMaxWidth()) { mm.cancel() }
                    PlainButton("Use the editor meanwhile", Modifier.fillMaxWidth()) { onContinue() }
                }
                else -> {
                    if (error != null) Text("Download failed: $error", color = Color(0xFFFF8F8F), fontSize = 12.sp)
                    OutlinedTextField(base, { base = it }, Modifier.fillMaxWidth(), label = { Text("Model address (R2 bucket)") }, singleLine = true)
                    AccButton("⬇ Download model (one time)", modifier = Modifier.fillMaxWidth()) {
                        App.prefs.modelBase = base.trim().ifEmpty { ModelManager.DEFAULT_BASE }
                        ParakeetEngine.unload()
                        if (Build.VERSION.SDK_INT >= 33) askNotif.launch(Manifest.permission.POST_NOTIFICATIONS) else mm.start()
                    }
                    PlainButton("Skip for now", Modifier.fillMaxWidth()) { onContinue() }
                }
            }
        }
    }
}
