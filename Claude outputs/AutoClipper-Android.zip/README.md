# Auto Clipper — native Android app

A fully native Kotlin + Jetpack Compose port of the Auto Clipper web editor (`index.html`).
No WebView: decoding, transcription, rendering and export all run natively on the phone.

## Open & run
1. Android Studio (Ladybug 2024.2 or newer) → **File › Open** → this folder.
2. Let Gradle sync (it downloads Gradle 8.11.1, AGP 8.7.3, Kotlin 2.0.21). If Studio offers to upgrade AGP, accept.
3. Run on a real phone (Android 10 / API 29 or newer, arm64 recommended).

## Flow
Login (same backend as the site) → **one-time model download** → editor.

## The transcription model (downloaded once, then always local)
* Same files your website loads from Cloudflare R2:
  `encoder-model.int8.onnx`, `decoder_joint-model.int8.onnx`, `vocab.txt`
  (NVIDIA Parakeet TDT 0.6B v2, INT8, ≈670 MB).
* Downloaded by a WorkManager foreground job: survives leaving the app, resumes after a dropped
  connection (HTTP Range), verifies sizes, then writes a `ready.json` marker.
* Stored in the app's private storage (`files/models/parakeet-tdt-0.6b-v2-int8/`). It is never
  downloaded again unless you delete it (Settings › Manage Parakeet model) or clear app data.
* Runs with ONNX Runtime Android (CPU, 4 threads). The session is created once and kept in memory.
  On first load ONNX Runtime also saves an optimised copy (`encoder.optimized.onnx`) so later app
  starts load faster. (This uses roughly another 650 MB of storage; delete it any time, it is rebuilt.)
* The NeMo log-mel front end and TDT greedy decoding are ported from `onnx-asr` (the same model
  format parakeet.js uses); the mel features were checked against the reference implementation.
* Long audio is split at the quietest point every 20–30 s, so memory stays low on phones.

## Feature map (web → app)
| Web editor | Android |
|---|---|
| Source video, start, max length | `EditorViewModel.pickSource`, Settings |
| Auto-cut silence (strength, min gap) | `Core.makeRanges` on a 20 ms loudness envelope |
| ✨ Find hook lines (first 3 min, top 3, tap any line) | `findHooks`, `Core.hookScore`, `applyStart` |
| Frame ratio / hook text / handle / position sliders | `Renderer.layout`, `frameText` |
| Transcript (SRT, VTT, `[0:05]`, plain text) | `Core.parseTr` |
| Auto-transcribe (Parakeet) | `asr/ParakeetEngine` |
| Blur list + bleep | `Core.blCompile/markBlur`, blur in `Renderer`, bleep in `AudioMixer` |
| Captions: kinetic / karaoke / box / minimal / red keyword | `Renderer.drawCaptions` |
| Auto B-roll from captions (filename keywords, aliases, rules) | `BrMatch.index/events/plan` |
| Manual B-roll + auto-place | `addManualBroll`, `autoPlace` |
| Zoom in / out | `Core.zoomK` |
| Auto BGM (scored, ducked, faded) / Auto Hook SFX / transition SFX | `Library.scoreBgm`, `placeSfx`, `placeTrans`, `AudioMixer` |
| Timeline + edit report | `ui/Timeline.kt`, `report()` |
| Export 1080p / 4K, 30 / 60 fps, MP4 H.264 + AAC | `media/Exporter.kt` → saved to *Movies/AutoClipper* |

## Library (bgm, best hook, transitionsfx, broll)
Settings › Library source:
* **GitHub** (default `hackerjinuu/auto-clipper`, branch `main`): reads the folders straight from the
  repo. Add a token if the repo is private.
* **Website**: your deployed site address; reads `library.json` + `broll.json` (from `make-manifest.js`).
* **Phone**: pick a folder that contains the four folders.

Remote files are downloaded once into the app and reused; analysis (energy envelopes) is cached too.

## Code layout
```
asr/      NemoMel (log-mel), ParakeetEngine (ONNX Runtime + TDT decoding)
model/    ModelManager + resumable ModelDownloadWorker
media/    AudioDecoder (MediaCodec + resampler), FrameSource (hardware video frames), Exporter (MP4)
editor/   Core (pure ported logic), BRoll, Library, Renderer, AudioMixer, PreviewEngine, EditorViewModel
ui/       Compose screens: login, model, editor, timeline, dialogs
```

## Notes
* Preview plays the exact export mix (speech, bleeps, music ducking, SFX) and draws with the same
  renderer as the export, so what you see is what you export.
* Video frames are decoded by the hardware decoder straight into GPU buffers. If a phone does not
  support that, the app automatically falls back to a CPU path.
* Fonts: Android has no Impact / Arial Black / Georgia, so the caption fonts use the closest system
  fonts (condensed black, black, serif). Drop a .ttf into `res/font` and change `Renderer.captionFont`
  to use your exact font.
